import express from 'express';
import { config } from './config.js';

import configObj from 'config';
import { configMod } from './modular-config/index.js';
import { configSchemaVal } from './schema/config-schema.js';



console.log(`App Name: ${configObj.get('appName')}`);
console.log(`Signup Enabled: ${configObj.get('features.enableSignup')}`);


// Modular Config
console.log(`DB Host: ${configMod.database.host}`);
console.log(`Server Port: ${configMod.server.port}`);

// Joi Schema Config
console.log('JOI ', configSchemaVal);

const app = express();

app.get('/', (req, res) => {
    res.send(`App running in ${config.environment} on port ${config.port}`);
});

app.listen(config.port, () => {
    console.log(`Server is live on http://localhost:${config.port}`);
});

/*
Best Practice:
	•	Never commit .env files to Git; add them to .gitignore.
	•	For production, use secret management tools
     like AWS Secrets Manager or Azure Key Vault.
*/

// Configuration - NODE_ENV=production node server.js