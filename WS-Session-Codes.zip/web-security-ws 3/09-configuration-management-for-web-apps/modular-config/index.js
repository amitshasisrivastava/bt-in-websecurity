import { databaseConfig } from './db.js';
import { serverConfig } from './server.js';

export const configMod = {
    database: databaseConfig,
    server: serverConfig
};