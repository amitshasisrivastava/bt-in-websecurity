import grpc from '@grpc/grpc-js';
import protoLoader from '@grpc/proto-loader';

const packageDefinition = protoLoader.loadSync('user.proto',{
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    oneofs: true,
});
const userProto = grpc.loadPackageDefinition(packageDefinition).UserService;

const users = {
    '1': { user_id: '1', name: 'Amit', email: 'amit@yahoo.com' },
    '2': { user_id: '2', name: 'Ram', email: 'ram@yahoo.com' },
};

function getUser(call, callback) {
    console.log(call.request);
    console.log('User id ', call.request.user_id);
    const user = users[call.request.user_id];
    if (user) {
        callback(null, user);
    } else {
        callback({
            code: grpc.status.NOT_FOUND,
            details: 'User not found',
        });
    }
}

const server = new grpc.Server();
server.addService(userProto.service, { getUser });
server.bindAsync('0.0.0.0:50051', grpc.ServerCredentials.createInsecure(), () => {
    console.log('****** Server is running at http://localhost:50051');
   // server.start();
});