import grpc from '@grpc/grpc-js';
import protoLoader from '@grpc/proto-loader';

// Load the proto file with proper options
const packageDefinition = protoLoader.loadSync('user.proto', {
    keepCase: true,    // Maintain field case
    longs: String,     // Convert longs to string
    enums: String,     // Convert enums to string
    defaults: true,    // Use default values for missing fields
    oneofs: true       // Include oneof fields
});

// Load the package definition into a gRPC object
const userProto = grpc.loadPackageDefinition(packageDefinition).UserService;

// Create the client
const client = new userProto('localhost:50051', grpc.credentials.createInsecure());

// Make the RPC call
client.GetUser({ user_id: '1' }, (error, response) => {
    if (!error) {
        console.log('User:', response);
    } else {
        console.error('Error:', error.message);
    }
});