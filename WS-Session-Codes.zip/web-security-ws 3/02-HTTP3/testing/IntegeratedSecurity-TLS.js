import { createSecureServer } from 'http2';
import { readFileSync } from 'fs';
import { fetch } from 'undici';
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'; // Disable certificate validation
// Certificates
const cert = readFileSync('/Users/amitsrivastava/Documents/web-security-ws/00-HTTPS/cert/server.cert');
const key = readFileSync('/Users/amitsrivastava/Documents/web-security-ws/00-HTTPS/cert/server.key');

// QUIC Server (Optional - For testing locally)
const server = createSecureServer({
    allowHTTP1: false,
    allowHTTP2: true,
    allowHTTP3: true,
    cert,
    key,
});
server.listen(8443, () => console.log('HTTP/3 Server running on https://localhost:8443'));

// QUIC Client to CMS API
const testHttp3 = async () => {
    try {
        const response = await fetch('https://localhost:443/api/articles', {
            method: 'GET',
            headers: { 'User-Agent': 'Node-QUIC-Client' },
        });

        console.log('Status Code:', response.status);
        const body = await response.json();
        console.log('Response:', body);
    } catch (error) {
        console.error('HTTP/3 Test Error:', error);
    }
};

testHttp3();