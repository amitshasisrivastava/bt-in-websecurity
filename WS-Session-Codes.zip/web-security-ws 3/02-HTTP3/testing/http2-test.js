import http2 from 'http2';
import { performance } from 'perf_hooks';
import fs from 'fs';

// SSL Certificate Paths
const certPath = '/Users/amitsrivastava/Documents/web-security-ws/00-HTTPS/cert/server.cert';
const keyPath = '/Users/amitsrivastava/Documents/web-security-ws/00-HTTPS/cert/server.key';

// Test HTTP/2
const testHttp2 = async (url) => {
  console.log('Testing HTTP/2...');
  const client = http2.connect(url, {
    ca: fs.readFileSync(certPath),
    key: fs.readFileSync(keyPath),
  });

  const start = performance.now();
  const req = client.request({ ':path': '/api/articles' });

  req.on('response', (headers) => {
    console.log('Headers:', headers);
  });

  req.setEncoding('utf8');
  req.on('data', (chunk) => {
    console.log('Response Data:', chunk);
  });

  req.on('end', () => {
    const end = performance.now();
    console.log(`HTTP/2 Response Time: ${(end - start).toFixed(2)} ms`);
    client.close();
  });

  req.end();
};

// URL
const url = 'https://localhost';

// Run HTTP/2 Test
await testHttp2(url);