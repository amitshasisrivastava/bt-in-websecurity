import { exec } from "child_process";
/*
	real: Total elapsed time.
	•	user: Time spent in user-space processing.
	•	sys: Time spent in kernel-space processing.
  The real time represents the response time for the HTTP/3 request.
*/
async function testHttp3() {
  const command = `time quiche-client https://localhost:443/api/articles --no-verify`;

  console.log("Running:", command);

  exec(command, (error, stdout, stderr) => {
    if (error) {
      console.error("Error during HTTP/3 test:", error.message);
      return;
    }

    if (stderr) {
      console.error("stderr:", stderr);
    }

    console.log("Response from server:");
    console.log(stdout);
  });
}

testHttp3();