import { exec } from "child_process";

function makeRequest(command) {
  return new Promise((resolve, reject) => {
    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error(`Error: ${error.message}`);
        reject(error);
        return;
      }
      if (stderr) {
        console.error(`Stderr: ${stderr}`);
      }
      console.log(`Stdout: ${stdout}`);
      resolve(stdout);
    });
  });
}

async function simulateParallelRequests() {
  const commands = [
    "quiche-client https://localhost:443/api/articles/welcome --no-verify",
    "quiche-client https://localhost:443/api/articles --no-verify",
  ];

  try {
    const responses = await Promise.all(commands.map(makeRequest));
    console.log("All requests completed:");
    responses.forEach((response, index) => {
      console.log(`Response from request ${index + 1}:\n${response}`);
    });
  } catch (error) {
    console.error("An error occurred:", error.message);
  }
}

simulateParallelRequests();