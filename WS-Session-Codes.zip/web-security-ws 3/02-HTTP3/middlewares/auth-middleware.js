import jwt from 'jsonwebtoken';

export const verifyToken = (req, res, next) => {
    console.log('Token ', req.header('Authorization'));
    const token = req.header('Authorization');
    console.log('Token ', token);
    if (!token) return res.status(403).json({ message: 'No token provided' });

    try {
       
        next();
    } catch (error) {
        res.status(401).json({ message: 'Invalid token' });
    }
};