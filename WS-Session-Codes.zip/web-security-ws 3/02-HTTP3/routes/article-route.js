import express from 'express';
import Article from '../models/article.js';
import { verifyToken } from '../middlewares/auth-middleware.js';

const router = express.Router();

// Get all articles
router.get('/', async (req, res) => {
    console.log('Call For Article....');
    const articles = await Article.find();
    res.json(articles);
});

router.get('/welcome', (req, res)=>{
    console.log('Call For Welcome....');
    for(let i =1;i<=100000; i++){
        for(let j = 1; j<=100000; j++){

        }
    }
    res.json({message:'Welcome'});
});

// Get single article
router.get('/:id', async (req, res) => {
    const article = await Article.findById(req.params.id);
    res.json(article);
});

// Create a new article (requires authentication)
router.post('/', verifyToken, async (req, res) => {
    const { title, content, author } = req.body;
    const newArticle = new Article({ title, content, author });
    await newArticle.save();
    res.status(201).json(newArticle);
});

// Update an article (requires authentication)
router.put('/:id', verifyToken, async (req, res) => {
    const updatedArticle = await Article.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedArticle);
});

// Delete an article (requires authentication)
router.delete('/:id', verifyToken, async (req, res) => {
    await Article.findByIdAndDelete(req.params.id);
    res.status(204).send();
});

export default router;