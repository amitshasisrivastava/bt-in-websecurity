  import http2 from "http2";
  import fs from "fs";
  import path from 'path';
  import { fileURLToPath } from "url";
  // Define TLS certificate paths
  const __filename = fileURLToPath(import.meta.url);
  const __dirname = path.dirname(__filename);
  // Normalize the path to move out of the current directory
  const certDirectory = path.normalize(path.join(__dirname, "../cert"));
  // Paths for SSL certificates
  const sslOptions = {
      key: fs.readFileSync(path.join(certDirectory, "server.key")),
      cert: fs.readFileSync(path.join(certDirectory, "server.cert")),
  };

  // Create an HTTP/2 server
  const server = http2.createSecureServer(sslOptions);

  server.on("stream", (stream, headers) => {
    const path = headers[":path"];
    
    if (path === "/") {
      // Send a simple HTML response
      stream.respond({
        "content-type": "text/html",
        ":status": 200,
      });
      stream.end("<h1>Hello from HTTP/2 Server</h1>");
    } else if (path === "/style.css") {
      // Simulate server-push for a CSS file
      // See in Network Tab
      stream.respond({
        "content-type": "text/css",
        ":status": 200,
      });
      stream.end("body { font-family: Arial; background: lightblue; }");
    } else {
      // Handle 404
      stream.respond({ ":status": 404 });
      stream.end("Not Found");
    }
  });

  // Start the server
  server.listen(8443, () => {
    console.log("HTTP/2 Server running at https://localhost:8443");
  });