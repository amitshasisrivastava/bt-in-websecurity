import http2 from "http2";
import fs from "fs";
import path from "path";


import { fileURLToPath } from "url";
// Define TLS certificate paths
// Note : Modern browsers are deprecating HTTP/2 push.
// testing with curl, enable HTTP/2 with the --http2 flag.
// curl --http2 -k https://localhost:8443/
// Modern time - push not work in browser and curl disable server push by default
// u need to use old curl version or you can use 
// nghttp -v https://localhost:8443/
// This tool supports HTTP/2 server push and will log pushed streams received from the server.
// Define TLS certificate paths
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// Normalize the path to move out of the current directory
const certDirectory = path.normalize(path.join(__dirname, "../cert"));
// Paths for SSL certificates
const sslOptions = {
    key: fs.readFileSync(path.join(certDirectory, "server.key")),
    cert: fs.readFileSync(path.join(certDirectory, "server.cert")),
};


// Create HTTP/2 server
const server = http2.createSecureServer(sslOptions);

server.on("stream", (stream, headers) => {
    console.log(`New stream ID: ${stream.id}, Path: ${headers[":path"]}`);
  const path = headers[":path"];

  if (path === "/") {
    // Push additional resources
    stream.pushStream({ ":path": "/style.css" }, (err, pushStream) => {
      if (err) return;
      pushStream.respond({
        "content-type": "text/css",
        ":status": 200,
      });
      pushStream.end("body { font-family: Arial; background: lightblue; }");
    });

    // Respond to the main request
    stream.respond({
      "content-type": "text/html",
      ":status": 200,
    });
    stream.write('<h2> Sending a Data Frame (Binary Response)'); // Sends Binary Data
    stream.end(`<h1>Welcome to HTTP/2 Server Push</h1><link rel="stylesheet" href="/style.css">`);
  } else if (path === "/style.css") {
    // Handle requests for style.css (if not pushed successfully)
    stream.respond({
      "content-type": "text/css",
      ":status": 200,
    });
    stream.end("body { font-family: Arial; background: lightblue; }");
  } else {
    // Handle 404
    stream.respond({ ":status": 404 });
    stream.end("Not Found");
  }
});

server.listen(8443, () => {
  console.log("HTTP/2 server running at https://localhost:8443");
});