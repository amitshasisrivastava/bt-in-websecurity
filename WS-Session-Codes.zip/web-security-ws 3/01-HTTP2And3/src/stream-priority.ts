import http2 from "http2";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
// Define TLS certificate paths
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// Normalize the path to move out of the current directory
const certDirectory = path.normalize(path.join(__dirname, "../cert"));
// Paths for SSL certificates
const sslOptions = {
    key: fs.readFileSync(path.join(certDirectory, "server.key")),
    cert: fs.readFileSync(path.join(certDirectory, "server.cert")),
};

const server = http2.createSecureServer(sslOptions);

server.on("stream", (stream, headers) => {
  const requestPath = headers[":path"];
  // stream - odd (client request)
  // stream - even (server)
  console.log('Path is ', requestPath);
  if (requestPath === "/") {
    // Respond with HTML (high priority)
    stream.respond({
      "content-type": "text/html",
      ":status": 200,
    });
    stream.priority({ weight: 256 });
    stream.end(`<html><head><script src="/script.js" ></script><link rel="stylesheet" href="style.css"></head><body><h1>Welcome to HTTP/2 Prioritization</h1><img src="amit.jpg"></body></html>`);
  } else if (requestPath === "/style.css") {
    // Respond with CSS (high priority)
    stream.respond({
      "content-type": "text/css",
      ":status": 200,
    });
    stream.priority({ weight: 256 });
    stream.end("body { font-family: Arial; background: lightblue; }");
  } else if (requestPath === "/script.js") {
    // Respond with JavaScript (medium priority)
    stream.respond({
      "content-type": "application/javascript",
      ":status": 200,
    });
    stream.priority({ weight: 20 });
    stream.end("console.log('JavaScript Loaded');");
  } else if (requestPath === "/amit.jpg") {
    // Respond with an image (low priority)
    stream.respond({
      "content-type": "image/jpeg",
      ":status": 200,
    });
    stream.priority({ weight: 64 });
    
    const imagePath = path.join(__dirname, "amit.jpg");
    stream.end(fs.readFileSync(imagePath));
  } else {
    // Respond with 404 for other requests
    stream.respond({ ":status": 404 });
    stream.end("Not Found");
  }
});

server.listen(8443, () => {
  console.log("HTTP/2 server running at https://localhost:8443");
});