import http2, { Http2SecureServer, ServerHttp2Stream, IncomingHttpHeaders } from "http2";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

// Define TLS certificate paths
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Normalize the path to move out of the current directory
const certDirectory = path.normalize(path.join(__dirname, "../cert"));

// Paths for SSL certificates
const sslOptions = {
    key: fs.readFileSync(path.join(certDirectory, "server.key")),
    cert: fs.readFileSync(path.join(certDirectory, "server.cert")),
};
// Create HTTP/2 secure server
const server: Http2SecureServer = http2.createSecureServer(sslOptions);

server.on("stream", (stream: ServerHttp2Stream, headers: IncomingHttpHeaders) => {
  const path = headers[":path"]; // Get the requested path
  const streamId = stream.id; // Stream ID for logging

  if (path === "/index.html") {
    console.log(`Stream ID ${streamId}: Serving index.html`);
    stream.respond({
      "content-type": "text/html",
      ":status": 200,
    });
    stream.end("<h1>Welcome to HTTP/2</h1>");
  } else if (path === "/style.css") {
    console.log(`Stream ID ${streamId}: Serving style.css`);
    stream.respond({
      "content-type": "text/css",
      ":status": 200,
    });
    stream.end("body { font-family: Arial; }");
  } else {
    console.log(`Stream ID ${streamId}: 404 Not Found`);
    stream.respond({ ":status": 404 });
    stream.end("Not Found");
  }
});

// Start the server
server.listen(8443, () => {
  console.log("HTTP/2 Server running at https://localhost:8443");
});