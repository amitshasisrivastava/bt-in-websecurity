import { WebSocketServer } from 'ws';

// Initialize WebSocket server
const wss = new WebSocketServer({ port: 8080 });

console.log('WebSocket server is running on ws://localhost:8080');

// Store connected clients
const clients = new Set();

// Handle new client connections
wss.on('connection', (ws) => {
    console.log('New client connected');
    clients.add(ws);

    // Send a welcome message to the client
    ws.send(JSON.stringify({ message: 'Welcome to the chat server!' }));

    // Broadcast function to send messages to all connected clients
    const broadcast = (message, sender) => {
        for (const client of clients) {
            if (client !== sender && client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify({ message }));
            }
        }
    };

    // Handle incoming messages
    ws.on('message', (data) => {
        const parsedData = JSON.parse(data);
        console.log(`Received message: ${parsedData.message}`);
        // Broadcast the message to other clients
        broadcast(parsedData.message, ws);
    });

    // Handle client disconnection
    ws.on('close', () => {
        console.log('Client disconnected');
        clients.delete(ws);
    });
});