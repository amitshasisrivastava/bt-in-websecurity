import grpc from '@grpc/grpc-js';
import protoLoader from '@grpc/proto-loader';

const packageDefinition = protoLoader.loadSync('stock.proto', {
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    oneofs: true,
});
const stockProto = grpc.loadPackageDefinition(packageDefinition).StockService;

// Simulate stock price updates
function getRandomPrice() {
    return (Math.random() * 1000).toFixed(2); // Random price between 0 and 1000
}

function getCurrentTimestamp() {
    return new Date().toISOString(); // ISO timestamp
}

// Streaming stock prices
function streamStockPrices(call) {
    const symbol = call.request.symbol;

    console.log(`Client subscribed to ${symbol} updates`);

    // Send updates every 2 seconds
    const interval = setInterval(() => {
        const price = getRandomPrice();
        const response = {
            symbol,
            price: parseFloat(price),
            timestamp: getCurrentTimestamp(),
        };

        call.write(response); // Stream the update
        console.log(`Sent update for ${symbol}:`, response);
    }, 2000);

    // Handle client disconnection
    call.on('cancelled', () => {
        console.log(`Client unsubscribed from ${symbol} updates`);
        clearInterval(interval);
    });
}

// Start the gRPC server
const server = new grpc.Server();
server.addService(stockProto.service, { StreamStockPrices: streamStockPrices });
server.bindAsync('0.0.0.0:50051', grpc.ServerCredentials.createInsecure(), () => {
    console.log('Server running at http://localhost:50051');
    server.start();
});