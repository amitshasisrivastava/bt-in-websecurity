import grpc from '@grpc/grpc-js';
import protoLoader from '@grpc/proto-loader';

const packageDefinition = protoLoader.loadSync('stock.proto', {
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    oneofs: true,
});
const stockProto = grpc.loadPackageDefinition(packageDefinition).StockService;

// Create the gRPC client
const client = new stockProto('localhost:50051', grpc.credentials.createInsecure());

// Subscribe to stock price updates
const call = client.StreamStockPrices({ symbol: 'Apple' });

call.on('data', (response) => {
    console.log(`Received update: ${response.symbol} - $${response.price} at ${response.timestamp}`);
});

call.on('error', (error) => {
    console.error('Error:', error.message);
});

call.on('end', () => {
    console.log('Stream ended by server');
});