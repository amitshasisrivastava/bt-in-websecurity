import express from "express";

const router = express.Router();


// Mock login route
router.post("/login", (req, res) => {
  const { username, password } = req.body;

  // Simulate user authentication
  if (username === "admin" && password === "password") {
    // Regenerate session ID to prevent session fixation
    req.session.regenerate((err) => {
      if (err) {
        return res.status(500).json({ error: "Session regeneration failed." });
      }

      // Store user data in the session
      req.session.user = { username };
      res.status(200).json({ message: "Login successful!" });
    });
  } else {
    res.status(401).json({ error: "Invalid credentials." });
  }
});

export default router;