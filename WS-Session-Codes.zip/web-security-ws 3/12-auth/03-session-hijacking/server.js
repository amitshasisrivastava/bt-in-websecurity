import express from "express";
import session from "express-session";
import helmet from "helmet";
import dotenv from "dotenv";
import crypto from "crypto";
import cookieParser from "cookie-parser";
import { sessionTimeout } from "./middlewares/session-timeout.js";
import { sessionValidation } from "./middlewares/session-validate.js";
dotenv.config();

const app = express();

// Middleware
app.use(express.json());
app.use(cookieParser());
app.use(helmet()); // Add security headers

// Secure session configuration
app.use(
  session({
    name: "sessionId", // Custom session cookie name
    secret: process.env.SESSION_SECRET || crypto.randomBytes(64).toString("hex"), // Secret key for signing cookies
    resave: false, // Do not save the session if it wasn't modified
    saveUninitialized: false, // Do not save uninitialized sessions
    cookie: {
      httpOnly: true, // Prevent JavaScript access to cookies
      secure: process.env.NODE_ENV === "production", // Use HTTPS in production
      sameSite: "strict", // Prevent CSRF by ensuring cookies are only sent in first-party requests
      maxAge: 15 * 60 * 1000, // Session expires in 15 minutes
    },
  })
);

// Sample route
app.get("/", (req, res) => {
  res.status(200).send("Welcome to the secure session management demo!");
});



app.use(sessionValidation);

app.use(sessionTimeout);
// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});