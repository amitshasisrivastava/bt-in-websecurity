export const sessionTimeout = (req, res, next) => {
    if (req.session) {
      const now = Date.now();
      const maxInactiveTime = 15 * 60 * 1000; // 15 minutes
  
      // Check last activity timestamp
      if (req.session.lastActivity && now - req.session.lastActivity > maxInactiveTime) {
        req.session.destroy(); // Destroy session if inactive for too long
        return res.status(401).json({ error: "Session expired due to inactivity." });
      }
  
      // Update last activity timestamp
      req.session.lastActivity = now;
    }
  
    next();
  };