export const sessionValidation = (req, res, next) => {
    const currentIP = req.ip;
    const currentUserAgent = req.headers["user-agent"];
  
    // Check if session data exists
    if (!req.session.clientInfo) {
      req.session.clientInfo = { ip: currentIP, userAgent: currentUserAgent };
    } else {
      const { ip, userAgent } = req.session.clientInfo;
  
      // Validate IP and User-Agent
      if (ip !== currentIP || userAgent !== currentUserAgent) {
        req.session.destroy();
        return res.status(401).json({ error: "Session invalidated due to suspicious activity." });
      }
    }
  
    next();
  };