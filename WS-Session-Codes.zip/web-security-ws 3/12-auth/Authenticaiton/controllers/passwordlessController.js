import nodemailer from "nodemailer";
import jwt from "jsonwebtoken";

const transporter = nodemailer.createTransport({
  service: process.env.EMAIL_SERVICE,
  auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS },
});

export const passwordlessLogin = async (req, res) => {
  const { email } = req.body;
  const token = jwt.sign({ email }, process.env.JWT_SECRET, {
    expiresIn: "15m",
  });

  await transporter.sendMail({
    to: email,
    subject: "Login Link",
    text: `Click this link to log in: http://localhost:${process.env.PORT}/auth/passwordless/verify?token=${token}`,
  });

  res.send("Login link sent");
};

export const passwordlessVerify = (req, res) => {
  const { token } = req.query;
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    res.send(`Login successful for email: ${payload.email}`);
  } catch {
    res.status(401).send("Invalid or expired token");
  }
};
