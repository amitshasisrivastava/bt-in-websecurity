import redisClient from "../config/redis.js";
import User from "../models/userModel.js";
import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  service: process.env.EMAIL_SERVICE,
  auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS },
});

export const mfaSendOtp = async (req, res) => {
  const { username } = req.body;
  const user = await User.findOne({ username });
  if (!user) return res.status(404).send("User not found");
  
  const otp = Math.floor(100000 + Math.random() * 900000).toString(); // UUID or nanoId (Package)
  await redisClient.setEx(`otp:${username}`, 300, otp); // Valid for 5 minutes

  

  await transporter.sendMail({
    to: user.username,
    subject: "Your OTP Code",
    text: `Your OTP is ${otp}`,
  });

  res.send("OTP sent");
};

export const mfaVerifyOtp = async (req, res) => {
  const { username, otp } = req.body;
  const storedOtp = await redisClient.get(`otp:${username}`);
  if (otp !== storedOtp) return res.status(401).send("Invalid OTP");

  res.send("OTP verified, authentication successful");
};
