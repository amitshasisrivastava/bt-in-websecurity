import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import User from "../models/userModel.js";

// Register a new user
export const registerUser = async (req, res) => {
  try {
    const { username, password } = req.body;
    // Validates input fields (username, password).
    if (!username || !password) {
      return res.status(400).json({
        error: "Missing required fields",
        details: "Both username and password are required",
      });
    }

    // Check if the user already exists
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({
        error: "Registration failed",
        details: "Username already exists",
      });
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 8);
    console.log("Registration - Password hashed successfully");

    // Create and save new user
    const newUser = new User({
      username,
      password: hashedPassword,
    });

    await newUser.save();
    console.log("Registration - New user saved successfully:", username);

    res.status(201).json({
      message: "User registered successfully",
      username,
    });
  } catch (error) {
    console.error("Registration error:", error);
    res.status(500).json({
      error: "Registration failed",
      details: error.message,
    });
  }
};

// JWT Login
export const jwtLogin = async (req, res) => {
  try {
    const { username, password } = req.body;

    // Validate input
    if (!username || !password) {
      return res.status(400).json({
        error: "Missing credentials",
        details: "Both username and password are required",
      });
    }

    // Find the user
    const user = await User.findOne({ username });

    // Debug logs
    console.log("Login attempt for username:", username);
    console.log("User found in database:", user ? "Yes" : "No");

    if (!user) {
      return res.status(401).json({
        error: "Authentication failed",
        details: "User not found",
      });
    }

    // Compare passwords
    const isPasswordValid = await bcrypt.compare(password, user.password);
    console.log("Password verification result:", isPasswordValid);

    if (!isPasswordValid) {
      return res.status(401).json({
        error: "Authentication failed",
        details: "Invalid password",
      });
    }

    // Generate JWT token
    const token = jwt.sign(
      {
        userId: user._id,
        username: user.username,
      },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );

    console.log("Login successful for user:", username);

    res.json({
      message: "Login successful",
      token,
      username: user.username,
    });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({
      error: "Login failed",
      details: error.message,
    });
  }
};

// Middleware to verify JWT token
export const verifyToken = async (req, res, next) => {
  try {
    const authHeader = req.header("Authorization");
    const token = authHeader?.replace("Bearer ", "");

    if (!token) {
      return res.status(401).json({
        error: "Access denied",
        details: "No token provided",
      });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Verify user still exists in database
    const user = await User.findById(decoded.userId);
    if (!user) {
      return res.status(401).json({
        error: "Access denied",
        details: "User no longer exists",
      });
    }

    req.user = decoded;
    next();
  } catch (error) {
    console.error("Token verification error:", error);
    res.status(401).json({
      error: "Access denied",
      details: "Invalid token",
    });
  }
};

// Protected Route example
export const jwtProtectedRoute = (req, res) => {
  res.json({
    message: "Access granted",
    user: {
      userId: req.user.userId,
      username: req.user.username,
    },
  });
};
