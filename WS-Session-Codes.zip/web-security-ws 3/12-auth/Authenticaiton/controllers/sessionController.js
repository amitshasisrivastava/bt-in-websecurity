import bcrypt from "bcrypt";
import User from "../models/userModel.js";

export const sessionLogin = async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.status(401).send("Invalid credentials");
  }
  req.session.userId = user._id;
  res.send("Logged in successfully");
};

export const sessionLogout = (req, res) => {
  req.session.destroy((err) => {
    if (err) return res.status(500).send("Error logging out");
    res.send("Logged out successfully");
  });
};

export const sessionProtectedRoute = (req, res) => {
  if (!req.session.userId) return res.status(401).send("Unauthorized");
  res.send("Access granted to protected resource");
};
