import mongoose from "mongoose";

const connectDB = async () => {
  try {
    // Connects to MongoDB using mongoose with the connection string (MONGO_URI) from the .env file.
    await mongoose.connect(process.env.MONGO_URI);
    console.log("MongoDB connected"); // On successful connection, logs a success message.
  } catch (err) {
    // If an error occurs, it logs the error and exits the process.
    console.error(err.message);
    process.exit(1);
  }
};

export default connectDB;
