import { createClient } from "redis";

// Uses createClient from the Redis library to establish a connection to the Redis server.
const redisClient = createClient({ url: process.env.REDIS_URI });

// Listens for errors and logs them if any occur.
redisClient.on("error", (err) => console.error("Redis error:", err));
await redisClient.connect();

export default redisClient;
