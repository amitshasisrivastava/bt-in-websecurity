import express from "express";
import https from "https";
import fs from "fs";
import path from "path";

const app = express();

// Middleware to parse JSON
app.use(express.json());

// Load server and CA certificates
const serverOptions = {
  key: fs.readFileSync(path.resolve("./certificates/server.key")), // Server private key
  cert: fs.readFileSync(path.resolve("./certificates/server.crt")), // Server certificate
  ca: fs.readFileSync(path.resolve("./certificates/ca.crt")), // Certificate Authority certificate
  requestCert: true, // Request client certificate
  rejectUnauthorized: true, // Reject clients without valid certificates
};

// Certificate-Protected Route
app.get("/cert-protected", (req, res) => {
  if (!req.client.authorized) {
    return res.status(401).json({
      error: "Access denied",
      details: "Client certificate not authorized",
    });
  }

  // Fetch client certificate details
  const clientCert = req.socket.getPeerCertificate();
  if (!clientCert.subject) {
    return res.status(400).json({
      error: "No client certificate provided",
    });
  }

  res.json({
    message: "Access granted",
    client: {
      subject: clientCert.subject,
      issuer: clientCert.issuer,
      valid_from: clientCert.valid_from,
      valid_to: clientCert.valid_to,
    },
  });
});

// Start HTTPS Server
const httpsServer = https.createServer(serverOptions, app);

httpsServer.listen(8443, () => {
  console.log("HTTPS server running on port 8443");
});
