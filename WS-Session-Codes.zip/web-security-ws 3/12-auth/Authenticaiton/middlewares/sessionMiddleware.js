import express from "express";
import session from "express-session";
import MongoDBStore from "connect-mongodb-session";
import dotenv from "dotenv";

// Load environment variables from .env file
dotenv.config();

// Create an instance of the MongoDBStore session store
const MongoDBSession = MongoDBStore(session);

// Ensure MONGO_URI is loaded correctly from .env file
if (!process.env.MONGO_URI) {
  throw new Error("MONGO_URI not defined in the .env file");
}

// Create a session store using the Atlas connection string
const store = new MongoDBSession({
  uri: process.env.MONGO_URI, // Your MongoDB Atlas connection string
  collection: "sessions", // The collection name in MongoDB to store sessions
});

// Configure session middleware
const sessionMiddleware = session({
  secret: "your-session-secret", // Replace with a secret key for better security
  resave: false, // Don't save session if unmodified
  saveUninitialized: false, // Don't save uninitialized sessions
  store: store, // Store session in MongoDB
  cookie: {
    secure: false, // Use `true` if using HTTPS
    httpOnly: true, // Ensure the cookie cannot be accessed via JavaScript
    maxAge: 1000 * 60 * 60 * 24, // Set cookie expiration time (1 day)
  },
});

export default sessionMiddleware;
