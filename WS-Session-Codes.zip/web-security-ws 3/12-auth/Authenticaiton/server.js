import express from "express";
import dotenv from "dotenv";

import connectDB from "./config/db.js";

import sessionMiddleware from "./middlewares/sessionMiddleware.js";
import sessionAuthRoutes from "./routes/sessionAuthRoutes.js";
import jwtAuthRoutes from "./routes/jwtAuthRoutes.js";
import mfaAuthRoutes from "./routes/mfaAuthRoutes.js";
import passwordlessAuthRoutes from "./routes/passwordlessAuthRoutes.js";

// this file is the main entry point of the project

// Load environment variables
dotenv.config();
connectDB();

process.on('uncaughtException', err=>{
    // log it the error
});
process.on('exit', ()=>{
    // log it , time stamp
})
const app = express();
// Middleware
app.use(express.json());
app.use(sessionMiddleware);

// Routes
app.use("/auth/session", sessionAuthRoutes); // Session based (Web Based)
app.use("/auth/jwt", jwtAuthRoutes); // Token Based (Mobile, Desktop , Embeded) + HTTPS, Helmet (CSP), CSURF (Request Tokens)
app.use("/auth/mfa", mfaAuthRoutes);
app.use("/auth/passwordless", passwordlessAuthRoutes);
app.use((err, req , res, next )=>{
    res.status(500).json({error:"Something went wrong"});
    // log the error
})
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
