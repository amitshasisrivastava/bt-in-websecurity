import express from "express";
import {
  jwtLogin,
  jwtProtectedRoute,
  registerUser,
} from "../controllers/jwtController.js";
import { jwtMiddleware } from "../middlewares/jwtMiddleware.js";

const jwtAuthRoutes = express.Router();

jwtAuthRoutes.post("/login", jwtLogin);
jwtAuthRoutes.post("/register", registerUser);
jwtAuthRoutes.get("/protected", jwtMiddleware, jwtProtectedRoute);

export default jwtAuthRoutes;
