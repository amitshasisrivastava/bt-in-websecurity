import express from "express";
import { mfaSendOtp, mfaVerifyOtp } from "../controllers/mfaController.js";

const mfaAuthRoutes = express.Router();

mfaAuthRoutes.post("/send-otp", mfaSendOtp);
mfaAuthRoutes.post("/verify-otp", mfaVerifyOtp);

export default mfaAuthRoutes;
