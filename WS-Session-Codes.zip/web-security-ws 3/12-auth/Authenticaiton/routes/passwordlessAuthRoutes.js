import express from "express";
import {
  passwordlessLogin,
  passwordlessVerify,
} from "../controllers/passwordlessController.js";

const passwordlessAuthRoutes = express.Router();

passwordlessAuthRoutes.post("/login", passwordlessLogin);
passwordlessAuthRoutes.get("/verify", passwordlessVerify);

export default passwordlessAuthRoutes;
