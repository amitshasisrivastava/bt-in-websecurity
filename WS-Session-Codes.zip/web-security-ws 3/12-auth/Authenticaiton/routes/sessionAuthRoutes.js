import express from "express";
import {
  sessionLogin,
  sessionLogout,
  sessionProtectedRoute,
} from "../controllers/sessionController.js";

const sessionAuthRoutes = express.Router();

sessionAuthRoutes.post("/login", sessionLogin);
sessionAuthRoutes.post("/logout", sessionLogout);
sessionAuthRoutes.get("/protected", sessionProtectedRoute);

export default sessionAuthRoutes;
