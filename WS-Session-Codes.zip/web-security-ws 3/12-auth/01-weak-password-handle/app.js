import express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import helmet from "helmet"; // Enhances API security by setting various HTTP headers
import rateLimit from "express-rate-limit"; // Prevent brute force attacks
import cookieParser from "cookie-parser";
import authRoutes from "./routes/auth.js"; // Authentication routes

dotenv.config(); // Load environment variables from .env file

const app = express();

// Middleware
app.use(express.json()); // Parse incoming JSON requests
app.use(cookieParser()); // Parse cookies
app.use(helmet()); // Add security headers

// Rate limiter to protect login and registration endpoints from brute-force attacks
const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // Limit each IP to 10 requests per window
  message: "Too many attempts, please try again later.",
});
app.use("/api/auth", authRateLimiter); // Apply rate limiting to auth routes

// Database Connection
mongoose
  .connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("Database connected successfully"))
  .catch((error) => console.error("Database connection failed:", error));

// Routes
app.use("/api/auth", authRoutes); // Mount authentication routes

// Default route
app.get("/", (req, res) => {
  res.status(200).send("Welcome to the Secure Node.js API!");
});

// Error handler for undefined routes
app.use((req, res) => {
  res.status(404).json({ error: "Route not found." });
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});