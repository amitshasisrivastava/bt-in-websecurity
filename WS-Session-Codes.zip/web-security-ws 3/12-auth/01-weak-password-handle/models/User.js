import mongoose from "mongoose";
import bcrypt from "bcrypt";

// Define password strength criteria
const validatePassword = (password) => {
  const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  return regex.test(password);
};

// User schema
const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
});

// Pre-save middleware to hash password and validate strength
userSchema.pre("save", async function (next) {

  //It ensures that the password hashing process is only triggered when 
  //the password field is modified.
  // this - document instance being saved to the database
  // isModified(field): A Mongoose method that checks if the specified field
  // (password in this case) has been modified since the document was loaded or created.
  if (!this.isModified("password")) return next();

  // Validate password strength
  if (!validatePassword(this.password)) {
    throw new Error(
      "Password must be at least 8 characters long, and include uppercase, lowercase, number, and special character."
    );
  }

  // Hash the password
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

// Method to compare passwords during login
userSchema.methods.comparePassword = async function (candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

export default mongoose.model("User", userSchema);