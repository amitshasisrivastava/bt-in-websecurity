import { verifyTOTP } from "../utils/mfa.js";

router.post("/login", async (req, res) => {
  try {
    const { email, password, token } = req.body;

    const user = await User.findOne({ email });
    if (!user || !(await user.comparePassword(password))) {
      return res.status(401).json({ error: "Invalid email or password" });
    }

    // Check if MFA is enabled for the user
    if (user.mfaEnabled) {
      if (!token || !verifyTOTP(token, user.mfaSecret)) {
        return res.status(401).json({ error: "Invalid or missing MFA token" });
      }
    }

    const authToken = jwt.sign(
      { id: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN }
    );

    res.status(200).json({ token: authToken });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});