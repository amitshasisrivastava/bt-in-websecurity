import express from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";
import { loginRateLimiter } from "../middleware/rateLimiter.js";

dotenv.config();

const router = express.Router();

// Mock User Database
const users = [
  { id: 1, email: "test@example.com", password: "$2b$12$abcdef...hashedpassword" }, // bcrypt hashed
];

// Login route
router.post("/register", async (req, res) => {
    try {
      const { email, password } = req.body;
  
      if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required." });
      }
  
      // Check if the password has been breached
      const breached = await isPasswordBreached(password);
      if (breached) {
        return res.status(400).json({
          error: "This password has been compromised in a data breach. Please choose a different password.",
        });
      }
  
      // Hash the password and save the user (mock example)
      const hashedPassword = await bcrypt.hash(password, 12);
      const user = { email, password: hashedPassword }; // Save user in DB
      console.log("User registered:", user);
  
      res.status(201).json({ message: "User registered successfully!" });
    } catch (error) {
      res.status(500).json({ error: "An error occurred during registration." });
    }
  });
  
  export default router;