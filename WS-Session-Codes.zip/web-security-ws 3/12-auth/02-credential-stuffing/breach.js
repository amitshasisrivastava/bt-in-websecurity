import axios from "axios";
import crypto from "crypto";
// breached password like 123456.
// unique password like SecurePass@2024.
// Check if a password has been compromised
export const isPasswordBreached = async (password) => {
  // Hash the password using SHA1
  const sha1Password = crypto.createHash("sha1").update(password).digest("hex").toUpperCase();
  const prefix = sha1Password.substring(0, 5);
  const suffix = sha1Password.substring(5);

  // Query the Have I Been Pwned API
  const url = `https://api.pwnedpasswords.com/range/${prefix}`;
  const response = await axios.get(url);
  const breachedPasswords = response.data.split("\n");

  // Check if the suffix exists in the response
  return breachedPasswords.some((entry) => entry.startsWith(suffix));
};
/*
What is the Pwned Passwords API?

The Pwned Passwords API provides access to a database of over 600 million real-world 
passwords that have been leaked in data breaches. These passwords are hashed 
and searchable through the API to ensure privacy.

Using the API, you can check if a password has been exposed in a breach 
without sending the full password to the server. This is achieved using 
the k-anonymity model.

How Does the API Work?

The API works by hashing a password using the SHA-1 algorithm, then splitting the 
hash into two parts:
	1.	First 5 Characters: Sent to the API to search for matching hash prefixes.
	2.	Remaining Characters: Used locally to check for a match in the API’s response.

This ensures that the full password is never exposed during the request.
*/

/*
Benefits of Using the Pwned Passwords API

	1.	Enhanced Security: Prevents users from using weak or compromised passwords.
	2.	Privacy First: K-anonymity ensures that the full password is never sent over the network.
	3.	Scalability: Free for most use cases with a large dataset of known breached passwords.
	4.	Ease of Integration: Lightweight and easy to implement in any application.
*/