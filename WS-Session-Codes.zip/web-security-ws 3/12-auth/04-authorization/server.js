import express from "express";
import dotenv from "dotenv";
import mongoose from "mongoose";
import secureRoutes from "./src/routes/secure.js";
import resourceRoutes from "./src/routes/resource.js";
import { authenticate } from "./src/middleware/auth.js";

dotenv.config();

const app = express();
app.use(express.json());
app.use(cookieParser());

// Database connection
mongoose
  .connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("Database connected"))
  .catch((error) => console.error("Database connection error:", error));

// Protected routes
//app.use("/api/resource", authenticate, resourceRoutes);

// Database connection

// Protect routes
app.use("/secure", authenticate, secureRoutes);
app.use("/resource", authenticate, resourceRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});



/*
Testing

Testing the Defenses

RBAC Example:

	1.	Login as a user with role: "user".
	2.	Try accessing the /secure/admin route.
	•	Response: 403 Access denied.
	3.	Try accessing the /secure/user route.
	•	Response: 200 Welcome, User!

IDOR Example:

	1.	User A tries to access User B’s resource:
	•	Request: GET /resource/:id (where id is User B’s resource).
	•	Response: 403 You do not have access to this resource.
	2.	User A accesses their own resource:
	•	Response: 200 { ...resource details... }

*/