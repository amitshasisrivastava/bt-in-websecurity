import express from "express";
import { authorize } from "../middleware/authorize.js";
import { Roles } from "../config/roles.js";

const router = express.Router();

router.get("/admin", authorize([Roles.ADMIN]), (req, res) => {
  res.status(200).json({ message: "Welcome, Admin!" });
});

router.get("/user", authorize([Roles.USER, Roles.ADMIN]), (req, res) => {
  res.status(200).json({ message: "Welcome, User!" });
});

export default router;