import express from "express";
import Resource from "../models/Resource.js";
import { validateOwnership } from "../middleware/validate-ownership.js";

const router = express.Router();

// Create a new resource
router.post("/", async (req, res) => {
  try {
    const { name } = req.body;
    const owner = req.user.id;

    const resource = new Resource({ name, owner });
    await resource.save();

    res.status(201).json(resource);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get a resource by ID with ownership validation
router.get("/:id", validateOwnership, async (req, res) => {
  res.status(200).json(req.resource);
});

export default router;