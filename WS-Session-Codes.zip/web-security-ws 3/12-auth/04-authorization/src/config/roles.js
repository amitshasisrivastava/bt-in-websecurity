export const Roles = {
    USER: "user",
    ADMIN: "admin",
  };