// Define a Middleware for Role-Based Authorization (RBAC)
export const authorize = (roles = []) => {
    return (req, res, next) => {
      if (!roles.includes(req.user.role)) {
        return res.status(403).json({ error: "Access denied." });
      }
      next();
    };
  };