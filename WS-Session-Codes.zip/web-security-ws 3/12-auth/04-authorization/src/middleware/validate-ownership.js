import Resource from "../models/Resource.js";

export const validateOwnership = async (req, res, next) => {
  try {
    const resource = await Resource.findById(req.params.id);

    if (!resource) {
      return res.status(404).json({ error: "Resource not found." });
    }

    if (resource.owner.toString() !== req.user.id) {
      return res.status(403).json({ error: "You do not have access to this resource." });
    }

    req.resource = resource; // Attach resource to the request
    next();
  } catch (error) {
    res.status(400).json({ error: "Invalid request." });
  }
};