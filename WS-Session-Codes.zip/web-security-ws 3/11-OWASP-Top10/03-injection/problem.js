import express from "express";
import mysql from "mysql2/promise";

const app = express();
app.use(express.json());

const db = await mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "password",
  database: "testdb",
});

// Route vulnerable to SQL Injection
app.post("/login", async (req, res) => {
  const { username, password } = req.body;

  try {
    const query = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;
    const [rows] = await db.query(query);

    if (rows.length > 0) {
      res.status(200).send("Login successful");
    } else {
      res.status(401).send("Invalid credentials");
    }
  } catch (err) {
    console.error(err);
    res.status(500).send("Internal Server Error");
  }
});

app.listen(3000, () => console.log("Server running on port 3000"));