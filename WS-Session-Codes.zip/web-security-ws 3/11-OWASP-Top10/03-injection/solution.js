app.post("/login", async (req, res) => {
    const { username, password } = req.body;
  
    try {
      const query = `SELECT * FROM users WHERE username = ? AND password = ?`;
      const [rows] = await db.execute(query, [username, password]);
  
      if (rows.length > 0) {
        res.status(200).send("Login successful");
      } else {
        res.status(401).send("Invalid credentials");
      }
    } catch (err) {
      console.error(err);
      res.status(500).send("Internal Server Error");
    }
  });