import express from 'express';
import bodyParser from 'body-parser';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import rateLimit from 'express-rate-limit';
import Joi from 'joi';

const app = express();
app.use(bodyParser.json());

// Dummy in-memory data with hashed passwords
const users = [
    { id: 1, username: 'admin', password: bcrypt.hashSync('password123', 10) },
];

const JWT_SECRET = 'supersecretkey'; // Use env variables for secrets

// Rate limiter middleware
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
    message: 'Too many requests from this IP, please try again later.',
});
app.use(limiter);

// Input validation schema
const loginSchema = Joi.object({
    username: Joi.string().min(3).required(),
    password: Joi.string().min(6).required(),
});

// Login endpoint
app.post('/login', async (req, res) => {
    const { error, value } = loginSchema.validate(req.body);

    if (error) {
        return res.status(400).send({ message: error.details[0].message });
    }

    const { username, password } = value;
    const user = users.find((u) => u.username === username);

    if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).send('Invalid credentials');
    }

    // Generate JWT token
    const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '1h' });

    res.send({ message: 'Login successful', token });
});

// Middleware to authenticate JWT
const authenticateJWT = (req, res, next) => {
    const token = req.headers.authorization;

    if (!token) {
        return res.status(403).send('Unauthorized');
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch (err) {
        res.status(403).send('Invalid or expired token');
    }
};

// Access protected resource
app.get('/profile', authenticateJWT, (req, res) => {
    res.send({ message: `Welcome to your profile, ${req.user.username}` });
});

// Start server
app.listen(3000, () => console.log('Server running on http://localhost:3000'));



/*
Key Improvements

	1.	Password Hashing: Prevents storing plaintext passwords, mitigating credential leaks.
	2.	JWT Tokens: Provides a secure and scalable session management mechanism.
	3.	Rate Limiting: Protects against brute-force and denial-of-service attacks.
	4.	Input Validation: Ensures only valid data is processed by the server.
*/