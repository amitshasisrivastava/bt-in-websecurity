import express from 'express';
import bodyParser from 'body-parser';

const app = express();
app.use(bodyParser.json());

// Dummy in-memory data
const users = [
    { id: 1, username: 'admin', password: 'password123' }, // Weak credentials
];

let sessions = {}; // No proper session management

// Login endpoint with insecure design
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    // No input validation
    const user = users.find((u) => u.username === username && u.password === password);

    if (!user) {
        return res.status(401).send('Invalid credentials');
    }

    // Weak session token
    const sessionToken = Math.random().toString(36).substring(2);
    sessions[sessionToken] = user.id;

    res.send({ message: 'Login successful', token: sessionToken });
});

// Access protected resource
app.get('/profile', (req, res) => {
    const token = req.headers.authorization;

    if (!token || !sessions[token]) {
        return res.status(403).send('Unauthorized');
    }

    res.send({ message: 'Welcome to your profile' });
});

// Start server
app.listen(3000, () => console.log('Server running on http://localhost:3000'));




/*

Flaws in the Above Code

	1.	Weak Authentication: No hashing for passwords, uses plain-text passwords.
	2.	Session Management: Random strings as session tokens without expiration.
	3.	No Rate Limiting: API is vulnerable to brute-force attacks.
	4.	Lack of Input Validation: User input is not validated.

*/