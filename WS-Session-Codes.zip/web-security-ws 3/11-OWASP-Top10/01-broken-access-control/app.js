// app.js (Node.js with Express.js)

import express from 'express';
import bodyParser from 'body-parser';

const app = express();
app.use(bodyParser.json());

// Sample Users Data (Simulates Database)
const users = [
    { id: 1, role: 'user', name: 'Alice', borrowedBooks: ['Book A', 'Book B'] },
    { id: 2, role: 'user', name: 'Bob', borrowedBooks: ['Book C'] },
    { id: 3, role: 'admin', name: 'Admin User' }
];

// Middleware for Simulated Authentication
app.use((req, res, next) => {
    console.log('Userid ', req.query.userid);
    const userId = parseInt(req.query.userid); // User ID sent in headers
    req.user = users.find(user => user.id === userId);
    if (!req.user) return res.status(401).send({ error: 'Unauthorized' });
    next();
});





//Vulnerable Route: Get Borrowed Books (No Access Control), open for all users
app.get('/borrowed-books', (req, res) => {
    // Broken Access Control: Returns all users' data
    res.send(users.map(user => ({
        name: user.name,
        borrowedBooks: user.borrowedBooks
    })));
});

// to make it secure , add RBAC (Role Based Access Control) Middleware
// Middleware for Role-Based Access Control (RBAC)
// const authorize = (roles = []) => (req, res, next) => {
//     if (!roles.includes(req.user.role)) {
//         return res.status(403).send({ error: 'Access Forbidden' }); // Forbidden
//     }
//     next();
// };

// // // Route: Get Borrowed Books (Fixed)
// app.get('/borrowed-books', authorize(['user', 'admin']), (req, res) => {
//     if (req.user.role === 'user') {
//         // Regular user: Return only their borrowed books
//         return res.send({
//             name: req.user.name,
//             borrowedBooks: req.user.borrowedBooks
//         });
//     } else if (req.user.role === 'admin') {
//         // Admin: Return all users' borrowed books
//         return res.send(users.map(user => ({
//             name: user.name,
//             borrowedBooks: user.borrowedBooks || []
//         })));
//     }
// });


// Start the server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

/*
Key Improvements

	1.	RBAC Middleware:
	•	Restricts access based on user roles.
	•	Ensures only authorized roles access certain endpoints.
	2.	Resource Ownership Check:
	•	For regular users, access is limited to their resources only (req.user.borrowedBooks).
	3.	Error Handling:
	•	Return appropriate HTTP status codes (403 Forbidden for unauthorized access).
*/