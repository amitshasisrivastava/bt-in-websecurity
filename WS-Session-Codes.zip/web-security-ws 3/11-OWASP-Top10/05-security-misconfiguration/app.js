import express from 'express';
import dotenv from 'dotenv';
import helmet from 'helmet';
dotenv.config();

const app = express();

// 2. use helmet
//app.use(helmet());
/*
Helmet automatically sets security-related HTTP headers like:
	•	Strict-Transport-Security
	•	Content-Security-Policy
	•	X-Content-Type-Options
*/

// 3. disable unneccessary things
// Prevent Express from revealing its framework type
app.disable('x-powered-by');
const PORT = process.env.PORT || 3000;

// Basic Route
app.get('/', (req, res) => {
  res.send('Welcome to Secure Express App!');
});

// Example Route that causes an error
app.get('/error', () => {
  throw new Error('This is a sample error!');
});

//1. secure the middleware (error handling)
// app.use((err, req, res, next) => {
//     console.error(err.stack);
  
//     const response = {
//       message: 'Internal Server Error',
//       // Only expose stack trace in development
//       st:(process.env.NODE_ENV === 'development' && { stack: err.stack }),
//     };
  
//     res.status(500).json(response);
//   });
// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

// http://localhost:3000/error

//You’ll see a stack trace like this: