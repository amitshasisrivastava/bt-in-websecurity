import express from 'express';
import fetch from 'node-fetch';

const app = express();
app.use(express.json());

// Allowed domains for fetching images
const ALLOWED_HOSTS = ['brain-mentors.com', 'coding.brain-mentors.com'];

// Validate the URL format
const isValidUrl = (url) => {
    try {
        const parsedUrl = new URL(url);
        // Allow only HTTP and HTTPS protocols
        return ['http:', 'https:'].includes(parsedUrl.protocol);
    } catch {
        return false;
    }
};

// Check if the hostname is in the allowed list
const isAllowedHost = (url) => {
    try {
        const { hostname } = new URL(url);
        return ALLOWED_HOSTS.includes(hostname);
    } catch {
        return false;
    }
};

// Endpoint to fetch an image from a user-provided URL
app.post('/fetch-image', async (req, res) => {
    const { imageUrl } = req.body;

    try {
        // Validate the provided imageUrl
        if (!imageUrl || !isValidUrl(imageUrl)) {
            return res.status(400).json({ error: 'Invalid URL format' });
        }

        if (!isAllowedHost(imageUrl)) {
            return res.status(403).json({ error: 'URL not allowed' });
        }

        // Fetch the image with a timeout for security
        const response = await fetch(imageUrl, { timeout: 5000 });

        if (!response.ok) {
            return res.status(400).json({ error: 'Failed to fetch the image' });
        }

        const contentType = response.headers.get('content-type') || 'application/octet-stream';

        // Send the fetched image back to the client
        const imageBuffer = await response.buffer();
        res.writeHead(200, { 'Content-Type': contentType });
        res.end(imageBuffer);
    } catch (error) {
        console.error('Error fetching image:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Start the Express server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});



/*
How It Works

	1.	Input Validation: The isValidUrl function ensures the input is a valid HTTP or HTTPS URL.
	2.	Allowlist: The isAllowedHost function restricts requests to pre-approved domains defined in ALLOWED_HOSTS.
	3.	Fetch Security: A timeout is set for the fetch call to avoid long-running operations.
	4.	Error Handling: Proper error messages are sent to the client, avoiding exposure of internal server details.

*/
// Valid Request on postman JSON Body
/*
{
    "imageUrl": "https://example.com/image.png"
}
*/

/*
Invalid Request (e.g., internal IP):
{
    "imageUrl": "http://127.0.0.1:5000/internal-api"
}
*/