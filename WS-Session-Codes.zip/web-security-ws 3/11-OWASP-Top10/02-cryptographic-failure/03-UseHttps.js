import https from 'https';
import fs from 'fs';

const options = {
  key: fs.readFileSync('server-key.pem'),
  cert: fs.readFileSync('server-cert.pem'),
};

https.createServer(options, (req, res) => {
  res.writeHead(200);
  res.end('Secure Connection Established\n');
}).listen(443, () => {
  console.log('HTTPS server running on port 443');
});