// AES-GCM for Secure Encryption

import crypto from 'crypto';

// Define secure parameters
const algorithm = 'aes-256-gcm'; // Secure algorithm
const key = crypto.randomBytes(32); // Generate a secure 256-bit key
const iv = crypto.randomBytes(12); // Generate a secure IV (GCM uses 12 bytes)

const encrypt = (plaintext) => {
  const cipher = crypto.createCipheriv(algorithm, key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag(); // Get the authentication tag for integrity

  return {
    encryptedData: encrypted.toString('hex'),
    iv: iv.toString('hex'),
    authTag: authTag.toString('hex'),
  };
};

const decrypt = ({ encryptedData, iv, authTag }) => {
  const decipher = crypto.createDecipheriv(algorithm, key, Buffer.from(iv, 'hex'));
  decipher.setAuthTag(Buffer.from(authTag, 'hex')); // Set the authentication tag
  const decrypted = Buffer.concat([decipher.update(Buffer.from(encryptedData, 'hex')), decipher.final()]);

  return decrypted.toString('utf8');
};

// Example usage
const data = 'Hello Amit';
const encrypted = encrypt(data);
console.log('Encrypted:', encrypted);

const decrypted = decrypt(encrypted);
console.log('Decrypted:', decrypted);