import argon2 from 'argon2';

const hashPassword = async (password) => {
  return await argon2.hash(password); // Securely hash the password
};

const verifyPassword = async (hashedPassword, inputPassword) => {
  return await argon2.verify(hashedPassword, inputPassword); // Verify the password
};

// Example usage
(async () => {
  const password = 'SecurePassword123!';
  const hashed = await hashPassword(password);
  console.log('Hashed Password:', hashed);

  const isValid = await verifyPassword(hashed, 'SecurePassword123!');
  console.log('Password Valid:', isValid);
})();