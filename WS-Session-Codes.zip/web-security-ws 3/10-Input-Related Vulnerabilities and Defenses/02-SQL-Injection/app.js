/*
1. Data Theft

Problem

Attackers gain unauthorized access to sensitive data, such as user credentials, financial records, or personal information, by exploiting vulnerable queries.
*/
// Scenario: A login form with vulnerable SQL query.
// SELECT * FROM users WHERE username = 'user' AND password = 'password';

// An attacker inputs ' OR '1'='1 in both username and password fields.
// SELECT * FROM users WHERE username = '' OR '1'='1' AND password = '' OR '1'='1';


// Solution to be follow
/*
1.	Parameterized Queries (Prepared Statements)
Use ? placeholders to prevent injection.
Example :
*/
const sql = 'SELECT * FROM users WHERE username = ? AND password = ?';
db.query(sql, [username, password], (err, results) => {
    if (err) throw err;
    console.log(results);
});

/*
	2.	Input Validation
Validate and sanitize user inputs using libraries like validator.js.

*/

import validator from 'validator';

const username = req.body.username;
if (!validator.isAlphanumeric(username)) {
    throw new Error('Invalid input');
}

/*
3.	Escaping Special Characters
Escape dangerous characters using database-specific functions.
*/
const escapedInput = connection.escape(userInput); // MY SQL Driver code

/*
	4.	Use Object-Relational Mapping (ORM)
Use ORM tools like Sequelize or TypeORM to handle database queries securely.
Example (Sequelize):

*/
const user = await User.findOne({
    where: { username: req.body.username }
});

/*
	5.	Limit Database Permissions
Grant minimal permissions to the database user account.

	6.	Web Application Firewalls (WAF)
Use a WAF to detect and block malicious queries.

	7.	Monitor and Audit Logs
Regularly review logs to detect suspicious activities.
*/

/*
    8. 		Encrypt Sensitive Data
Store passwords and sensitive data in hashed form using libraries like bcrypt.
Example:
*/
import bcrypt from 'bcrypt';

const hashedPassword = await bcrypt.hash(password, 10);
const isValid = await bcrypt.compare(inputPassword, hashedPassword);



/*
2. Session Hijacking

Problem

Attackers use SQL Injection to manipulate session tokens stored in the database, allowing them to impersonate users or gain access to sensitive sessions.

Example Scenario

A session validation query is vulnerable to SQL Injection.

Vulnerable Query:
SELECT * FROM sessions WHERE session_id = 'abc123';

An attacker inputs:
abc123' UNION SELECT username, password, null FROM users--

Final Query 
SELECT * FROM sessions WHERE session_id = 'abc123'
UNION SELECT username, password, null FROM users;

	The attacker retrieves usernames and passwords from the users table.

*/

// Solution
/*
1.	Use Strong, Random Session Tokens
Use cryptographically secure random tokens and store their hashed versions in the database.
*/

import crypto from 'crypto';

const sessionToken = crypto.randomBytes(64).toString('hex');
const hashedToken = crypto.createHash('sha256').update(sessionToken).digest('hex');

/*
	2.	Validate Inputs
Ensure session tokens conform to expected patterns.
Example
*/
import validator from 'validator';

if (!validator.isAlphanumeric(sessionToken) || sessionToken.length !== 128) {
    throw new Error('Invalid session token format');
}

/*
	3.	Use Parameterized Queries
Avoid dynamically constructed queries. Instead, use prepared statements.
Example:
*/

const query = 'SELECT * FROM sessions WHERE session_id = ?';
db.query(query, [sessionToken], (err, results) => {
    if (err) throw err;
    if (results.length > 0) {
        res.send('Session valid');
    } else {
        res.status(401).send('Invalid session');
    }
});

/*

	4.	Implement Expiration for Sessions
Store session expiration times in the database and validate them.
Database Schema:

CREATE TABLE sessions (
    session_id VARCHAR(128),
    user_id INT,
    expires_at TIMESTAMP
);
*/

const querySession = 'SELECT * FROM sessions WHERE session_id = ? AND expires_at > NOW()';


/*
3. Phishing

Problem

SQL Injection can be used to modify application content or inject malicious links into the database, tricking users into providing sensitive information.

Example Scenario

A product page query is vulnerable, allowing attackers to inject malicious HTML/JavaScript.

Vulnerable Query:
SELECT product_name, product_description FROM products WHERE product_id = 101;

An attacker inputs:
101; UPDATE products SET product_description = '<a href="http://phishing-site.com">Click here</a>'--

Impact:
	•	The product_description is replaced with a phishing link.
	•	Users clicking the link are redirected to a malicious site.
*/

// Solution
/*
	1.	Escape Inputs
Sanitize inputs before embedding them in queries.
Example:
*/
const productId = req.body.productId;
const sanitizedInput = connection.escape(productId);

/*
	2.	Content Validation
Use input validation to ensure only valid content is allowed.
Example:
*/
const productDescription = req.body.description;
if (!validator.isLength(productDescription, { max: 500 })) {
    throw new Error('Invalid product description');
}

/*
	3.	Use ORM Libraries
ORM tools like Sequelize or Prisma prevent SQL Injection.
Example with Sequelize:
*/
const product = await Product.findByPk(req.body.productId);

/*
	4.	Content Security Policy (CSP)
Set a CSP header to restrict allowed sources of scripts.
Example:
*/
res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'");

/*
	5.	Audit Database Changes
Regularly monitor database updates for unauthorized modifications.
*/









// example

import express from 'express';
import mysql from 'mysql2/promise';

const app = express();
app.use(express.json());

// Database Connection
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'password',
    database: 'secure_db'
});

// Secure Route
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        // Using Parameterized Query
        const [results] = await db.execute(
            'SELECT * FROM users WHERE username = ? AND password = ?',
            [username, password]
        );

        if (results.length > 0) {
            res.send('Login Successful');
        } else {
            res.status(401).send('Invalid Credentials');
        }
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

app.listen(3000, () => console.log('Server running on port 3000'));