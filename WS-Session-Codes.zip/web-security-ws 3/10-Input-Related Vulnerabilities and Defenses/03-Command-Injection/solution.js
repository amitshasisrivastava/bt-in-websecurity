/*
	1.	Input Validation and Sanitization:
	•	Strictly validate and sanitize all user inputs using libraries like validator.js.
	•	Allow only expected characters or formats (e.g., regex matching).
*/

import validator from 'validator';

const isValidFileName = (input) => validator.matches(input, /^[a-zA-Z0-9_.-]+$/);

let userInput = "some_file.txt";
if (!isValidFileName(userInput)) {
    throw new Error("Invalid file name");
}

/*
	2.	Use Secure Command Execution APIs: (similar like prepared statement in SQL Injection)
	•	Prefer APIs like spawn or execFile in Node.js, 
    which separate command arguments from input, avoiding shell interpolation.
*/

import { execFile } from 'child_process';

 userInput = "some_file.txt"; // Controlled input
execFile('cat', [userInput], (error, stdout, stderr) => {
    if (error) {
        console.error(`Error: ${error.message}`);
        return;
    }
    console.log(`Output: ${stdout}`);
});

/*
Insecure command execution (e.g., using exec) often combines user input directly 
into a shell command, leading to command injection vulnerabilities.
 Secure APIs like spawn and execFile mitigate these risks by separating 
 the command from its arguments, preventing the shell from interpreting
  user-provided input as part of the command syntax.

  1. execFile

	•	Purpose: Directly executes a binary file or system command without spawning a shell.
	•	Advantage: Prevents shell interpolation, so user input cannot introduce malicious shell commands or characters.
	•	Use Case: Ideal for scenarios where a predefined binary (e.g., ls, cat) needs to be executed with controlled arguments.

    	•	Why Safe?
	•	The user input (fileName) is passed as an argument in an array.
	•	No shell is involved, so special characters like ; or & in fileName will not lead to command injection.


    2. spawn

	•	Purpose: Spawns a new child process and allows interaction with its input/output streams.
	•	Advantage: Provides fine-grained control over how commands are executed and how their input/output is managed, while avoiding shell involvement.
	•	Use Case: Best for long-running processes or when you need real-time access to input/output streams.

    */


    import { spawn } from 'child_process';

const fileName = "some_file.txt"; // User input

// Spawn the 'cat' command safely
const catProcess = spawn('cat', [fileName]);

// Capture and log the output
catProcess.stdout.on('data', (data) => {
    console.log(`Output: ${data}`);
});

// Handle errors
catProcess.stderr.on('data', (error) => {
    console.error(`Error: ${error}`);
});

catProcess.on('close', (code) => {
    console.log(`Process exited with code: ${code}`);
});


/*

Why Safe?
	•	The spawn method explicitly treats the second parameter ([fileName]) 
    as arguments for the command.
	•	No shell interpretation occurs, 
    so input like some_file.txt && rm -rf / would not execute maliciously.
*/

/*
When to Use Each API

	•	Use execFile for:
	•	Simple commands with predefined arguments.
	•	Tasks where real-time streaming of output is unnecessary.
	•	Use spawn for:
	•	Commands with long-running processes or large outputs.
	•	Scenarios where real-time data processing is required.
*/

/*
3.  Use Sandboxing

Run commands in a restricted environment where potential damage is minimized:
	•	Use containerization (e.g., Docker) to isolate processes.
	•	Use restricted permissions for the user or environment running the commands.

    # Create a restricted container for executing commands
docker run --rm -it --read-only alpine sh
*/

import { exec } from 'child_process';

 userInput = "some_file.txt";

// Run command in a container or restricted environment
exec(`docker run --rm -v $(pwd):/app alpine cat /app/${userInput}`, (error, stdout, stderr) => {
    if (error) {
        console.error(`Error: ${error.message}`);
        return;
    }
    console.log(`Output: ${stdout}`);
});

/*
Command explain
1. docker run

	•	This is the command used to run a Docker container.

    2. --rm

	•	Automatically removes the container after it stops.
	•	Ensures that temporary containers do not consume unnecessary system resources.

    3. -v $(pwd):/app

	•	Mounts a volume from the host machine into the Docker container.

Explanation:

	•	$(pwd): Expands to the current working directory on the host machine. This is the directory where the command is executed.
	•	/app: The mount point inside the container where the host directory will be accessible.
	•	Effect: The contents of the current directory on your host system become available at /app inside the container.

For example:
	•	If you are in a directory containing a file example.txt, the container can access it at /app/example.txt.

    4. alpine

	•	Specifies the Docker image to use.
	•	Alpine is a lightweight Linux distribution commonly used for containerized environments due to its small size and simplicity.

    5. cat /app/${userInput}

	•	Runs the cat command inside the container to display the contents of the specified file.

    If userInput is example.txt, the command effectively runs:


    Advantages

	1.	Sandboxing:
	•	The command is executed in a containerized environment, isolated from the host system.
	•	Prevents harmful commands from affecting the host (e.g., malicious user input cannot delete host files directly).
	2.	Controlled File Access:
	•	The volume mount restricts the accessible files to the specific directory ($(pwd)) on the host.
	3.	Lightweight Execution:
	•	The alpine image ensures minimal overhead.
	4.	Ephemeral Execution:
	•	The container is temporary, ensuring a clean environment for each execution.

    */


    /*
    4. Implement Least Privilege

	•	Restrict the privileges of the application or process running the commands. Even if a command injection vulnerability is exploited, the attacker’s actions will be limited by the system’s permissions.

Example:

	•	Run the application with a non-root user.
	•	Use Role-Based Access Control (RBAC) for sensitive resources.
    */

    /*
    5. Command Execution Proxies

Use a controlled intermediate layer or service to execute commands safely. This approach isolates the execution logic from user inputs.

Example:

	•	Create a microservice with predefined commands that accept only specific arguments.
	•	Use APIs like GraphQL or REST to control access.
    */

    /*
    6. Security Libraries and Tools

	•	Use tools that detect or mitigate command injection vulnerabilities in your codebase.

Tools:

	•	Node.js Security Libraries:
	•	Helmet.js: For setting HTTP headers securely.
	•	npm audit: To identify vulnerable dependencies.
	•	Static Code Analysis:
	•	SonarQube: Identifies injection vulnerabilities.
	•	Snyk: Scans for security vulnerabilities in dependencies.
    */

    /*

    7. Monitoring and Logging

	•	Implement comprehensive logging and monitoring of command execution attempts.
	•	Detect unusual patterns that could indicate an attempted injection.

    */

    import fs from 'fs';

const logCommandExecution = (command) => {
    fs.appendFileSync('command_log.txt', `Command executed: ${command}\n`);
};

const command = "cat some_file.txt";
logCommandExecution(command);

/*
8. Content Security Policies (CSP)

If the attack vector involves injecting scripts that invoke commands, use CSP headers to block unauthorized content execution.
*/

const express = require('express');
const helmet = require('helmet');

const app = express();
app.use(helmet.contentSecurityPolicy({
    directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'"],
    },
}));


/*

Summary

To handle command injection effectively:
	•	Preferred Approach: Avoid shell commands where possible by using native Node.js libraries (e.g., fs, os).
	•	Validation & Sanitization: Strictly validate and sanitize all user inputs.
	•	Use Secure APIs: spawn, execFile, and others prevent shell interpolation.
	•	Least Privilege & Isolation: Run commands in a restricted, sandboxed environment.
	•	Proactive Security Tools: Leverage static analysis, security libraries, and runtime protection.
*/

