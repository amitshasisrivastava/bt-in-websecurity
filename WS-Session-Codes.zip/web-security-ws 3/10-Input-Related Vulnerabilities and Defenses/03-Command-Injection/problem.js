import { exec } from 'child_process';
// Vulnerable Code 
const userInput = "some_file.txt"; // Expected file name from the user
exec(`cat ${userInput}`, (error, stdout, stderr) => {
    if (error) {
        console.error(`Error: ${error.message}`);
        return;
    }
    if (stderr) {
        console.error(`Stderr: ${stderr}`);
        return;
    }
    console.log(`Output: ${stdout}`);
});

// attacker can input 
// some_file.txt; rm -rf /important_directory
// This would delete critical files on the system.