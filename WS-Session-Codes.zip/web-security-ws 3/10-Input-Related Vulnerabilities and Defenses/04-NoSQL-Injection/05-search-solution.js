
import express from 'express';
import Joi from 'joi';
import { MongoClient } from 'mongodb';

const app = express();
const client = new MongoClient('mongodb://localhost:27017');
await client.connect();
const db = client.db('test');
const users = db.collection('users');

// Define a schema for input validation using Joi
const searchSchema = Joi.object({
    q: Joi.string().pattern(/^[a-zA-Z0-9\s]+$/).min(1).max(50).required(), // Allow only alphanumeric and space
});

app.get('/search', async (req, res) => {
    const { error, value } = searchSchema.validate(req.query);

    if (error) {
        return res.status(400).json({ message: 'Invalid search query' });
    }

    const searchQuery = value.q;

    // Use a regex search for partial matches, preventing injection
    const results = await users
        .find({ name: { $regex: `^${searchQuery}`, $options: 'i' } }) // Case-insensitive search
        .toArray();

    res.json(results);
});

app.listen(3000, () => console.log('Server running on port 3000'));




/*
Best Practices

	1.	Always validate and sanitize input before using it in any query.
	2.	Avoid passing user input directly to query operators like $gt, $lt, $regex, etc.
	3.	Implement rate limiting to avoid abuse of search endpoints.
	4.	Return only necessary fields using projection to reduce exposure of sensitive data.
    */