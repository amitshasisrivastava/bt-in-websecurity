// 1. Input Validation
// 	Use strong validation libraries such as Joi or Zod to validate and sanitize input.

import Joi from 'joi';
import express from 'express';
import { MongoClient } from 'mongodb';

const app = express();
app.use(express.json());

const client = new MongoClient('mongodb+srv://admin:admin123@cluster0.zphslm3.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0');
await client.connect();
const db = client.db('test');
const users = db.collection('users');


const loginSchema = Joi.object({
    username: Joi.string().alphanum().min(3).max(30).required(),
    password: Joi.string().min(6).required(),
});

app.post('/joi-login', async (req, res) => {
    const { error, value } = loginSchema.validate(req.body);

    if (error) {
        return res.status(400).json({ message: error.details[0].message });
    }

    const { username, password } = value;
    const user = await users.findOne({ username, password });

    if (user) {
        res.json({ message: 'Login successful!' });
    } else {
        res.status(401).json({ message: 'Invalid credentials' });
    }
});

app.listen(3000, () => console.log('Server running on port 3000'));