import express from 'express';

import { MongoClient } from 'mongodb';
import sanitize from 'mongo-sanitize';

const app = express();
app.use(express.json());

const client = new MongoClient('mongodb+srv://admin:admin123@cluster0.zphslm3.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0');
await client.connect();
const db = client.db('test');
const users = db.collection('users');

app.post('/login-sanitize', async (req, res) => {
    const { username, password } = req.body;
    const sanitizedUsername = sanitize(username);
    const sanitizedPassword = sanitize(password);
    console.log(sanitizedUsername, " ---- ", sanitizedPassword);
    // Using parameterized query with exact match
    const user = await users.findOne({ 
        username: sanitizedUsername, 
        password: sanitizedPassword 
    });

    console.log('User ', user);

    if (user) {
        res.json({ message: 'Login successful!' });
    } else {
        res.status(401).json({ message: 'Invalid credentials' });
    }
});

app.listen(3000, () => console.log('Server running on port 3000'));


/*
4th way
4. Use Access Controls

	•	Implement role-based access control (RBAC) to restrict user permissions.
	•	Use JWT or OAuth for secure user authentication and authorization.
*/

/*
Final Words

Real-Time Use Cases

Scenario 1: Login Authentication

	•	Risk: Attackers gain unauthorized access by injecting { $ne: null }.
	•	Solution: Use parameterized queries and validate user input.

Scenario 2: Search Functionality

	•	Risk: Unsanitized user input could allow an attacker to retrieve all data using { $gt: '' }.
	•	Solution: Validate input to accept only specific characters and escape input.
*/


