// Search Problem - Vulnerable Code
/*
Attackers can exploit unsanitized search input by injecting a malicious query like { $gt: '' } to bypass
 filters and retrieve all data in the collection.

 If the user provides a query like { "$gt": "" }, the find function will match all documents where
  the name field exists, leaking the entire dataset.
*/
app.get('/search', async (req, res) => {
    const searchQuery = req.query.q;

    // Directly embedding user input into the query
    const results = await users.find({ name: searchQuery }).toArray();

    res.json(results);
});