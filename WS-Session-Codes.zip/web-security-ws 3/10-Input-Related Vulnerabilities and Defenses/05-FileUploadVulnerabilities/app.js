import express from 'express';
import multer from 'multer';
import {fileTypeFromBuffer} from 'file-type';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs';
import path from 'path';
import fsExtra from 'fs-extra';
import { fileURLToPath } from 'url';
import rateLimit from 'express-rate-limit';
import captchaMiddleware from './custom-captcha.js'; // Custom CAPTCHA middleware
import clamav from 'clamav.js'; 
// Define __dirname for ES module scope
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
app.use(express.static('public'));
app.use(express.json());
app.use(express.urlencoded({extended:true}));
const PORT = 3000;

// Directory for uploaded files (outside web root)  c. Secure Upload Directory
/*
	•	Store uploaded files in a directory outside the web root to prevent direct access.
	•	Example:
	•	Web root: /var/www/html
	•	Upload directory: /var/uploads
*/
const UPLOADS_DIR = path.resolve(__dirname, 'uploads'); // specify the path like /var/www/html
fsExtra.ensureDirSync(UPLOADS_DIR); // Ensure the directory exists

// Multer configuration
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOADS_DIR),
    filename: (req, file, cb) => {
      const uniqueFileName = `${uuidv4()}-${sanitizeFileName(file.originalname)}`;
      cb(null, uniqueFileName);
    },
  }),
  limits: { fileSize: 2 * 1024 * 1024 }, // 2MB limit
});

// Utility: Sanitize file name    b. File Name Sanitization
const sanitizeFileName = (fileName) => fileName.replace(/[^a-zA-Z0-9.\-_]/g, '_');

// Middleware: Rate Limiting
const uploadRateLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 10, // Limit each IP to 10 upload requests per window
    message: 'Too many upload requests. Please try again later.',
  });
  

// Middleware: Validate file type (a. Content-Type and File Type Validation)
const validateFileType = async (req, res, next) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded.' });
  }

  const uploadedFilePath = req.file.path;

  try {
    const buffer = await fs.promises.readFile(uploadedFilePath);
    const type = await fileTypeFromBuffer(buffer);

    console.log('File type:', type);

    if (!type || !['image/jpeg', 'image/png'].includes(type.mime)) {
      // Delete invalid files
      await fs.promises.unlink(uploadedFilePath);
      return res.status(400).json({ error: 'Invalid file type. Only JPEG/PNG allowed.' });
    }

    next(); // File is valid
  } catch (err) {
    next(err);
  }
};
/*
ClamAV is an open source (GPLv2) anti-virus toolkit, designed especially for e-mail scanning on mail gateways. It provides a number of utilities including a flexible and scalable multi-threaded daemon, a command line scanner and advanced tool for automatic database updates. 
The core of the package is an anti-virus engine available in a form of shared library.
ClamAV is designed to scan files quickly.
ClamAV detects millions of viruses, worms, trojans, and other malware,
*/
// ClamAV® is an open-source antivirus engine for detecting trojans, viruses, malware & other malicious threats.
// ClamAV Download from https://www.clamav.net/downloads#otherversions
// Middleware: Scan file with ClamAV - for malicious files upload prevention
// https://docs.clamav.net/manual/Installing.html
/*
	1.	Install ClamAV:
	•	Install and configure ClamAV on your system.
	•	Ensure the clamd daemon is running:
    In terminal type clamd (to start the Clam Anti Virus)
*/


const scanFileWithClamAV = async (req, res, next) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded.' });
  }

  const uploadedFilePath = req.file.path;

  try {
    // Ping the ClamAV daemon
    console.log('Clamav ', clamav.ping);
    
    clamav.ping(3310, '127.0.0.1', 5000,(err) => {
      if (err) {
        console.error('ClamAV daemon not reachable:', err.message);
        throw new Error('ClamAV server is not available.');
      }

      console.log('ClamAV server is reachable............');

      // Scan the file
      const stream = fs.createReadStream(uploadedFilePath);
      const scanner = clamav.createScanner(3310, '127.0.0.1');
      console.log('Scanner ', scanner);
      scanner.scan(stream, (err, result) => {
        if (err) {
          console.error('Error during file scanning:', err.message);
          return next(err);
        }
        if (result.isInfected) {
          console.log('File is infected with:', result.viruses);
          fs.unlinkSync(uploadedFilePath); // Delete the infected file
          return res.status(400).json({ error: `File contains malware: ${result.viruses.join(', ')}` });
        }

        console.log('File is clean.');
        next(); // File passed the scan
      });
    });
  } catch (err) {
    next(err); // Pass error to the error handling middleware
  }
};
  

// Endpoint: File Upload
app.post(
  '/upload',
  express.urlencoded({ extended: true }), // Parse non-file fields
  upload.single('file'), // Handle single file upload
  captchaMiddleware, // Validate CAPTCHA
  validateFileType, // Validate file type
  scanFileWithClamAV, // Scan file for malware
  (req, res) => {
    console.log('File uploaded:', req.file);
    console.log('CAPTCHA token:', req.body['g-recaptcha-response']);

    res.status(200).json({
      message: 'File uploaded successfully!',
      fileName: req.file.filename,
      filePath: `/uploads/${req.file.filename}`,
    });
  }
);
  



// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Something went wrong!', details: err.message });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});


/*
Features of This Example

	1.	Sanitized File Names: Prevent path traversal attacks.
	2.	File Type Validation: Validates content using magic numbers, not extensions.
	3.	Storage Outside Web Root: Files are stored securely in a non-web-accessible directory.
	4.	File Size Limit: Prevents DoS attacks from large file uploads.
	5.	Antivirus Simulation: Demonstrates real-world malware scanning.
	6.	Error Handling: Returns user-friendly error messages.

*/

/*
How It Works

	1.	Rate Limiting:
	•	Limits each IP to a maximum of 10 upload requests in a 15-minute window.
	•	Protects against DoS attacks.
	2.	CAPTCHA Verification:
	•	Uses Google reCAPTCHA to ensure the request is from a human.
	•	Adds a token in the front-end form that is verified on the server.
	3.	ClamAV Integration:
	•	Scans files for known malware signatures.
	•	Rejects files flagged as infected.
*/