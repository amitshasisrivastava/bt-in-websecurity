import axios from 'axios';
//https://www.google.com/recaptcha/admin
const validateCaptcha = async (req, res, next) => {
  try {
    console.log('Body:', req.body);

    const token = req.body['g-recaptcha-response']; // Extract CAPTCHA token
    if (!token) {
      return res.status(400).json({ error: 'CAPTCHA verification failed. Token missing.' });
    }

    const secretKey = '6Le2hIkqAAAAAM4yIbUE_uMDHbiZuXcKY_3g37LR'; // Replace with your secret key
    const response = await axios.post(
      'https://www.google.com/recaptcha/api/siteverify',
      {},
      { params: { secret: secretKey, response: token } }
    );

    if (!response.data.success) {
      return res.status(400).json({ error: 'CAPTCHA verification failed.', details: response.data['error-codes'] });
    }

    next(); // CAPTCHA passed
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'CAPTCHA verification error.', details: err.message });
  }
};

export default validateCaptcha;