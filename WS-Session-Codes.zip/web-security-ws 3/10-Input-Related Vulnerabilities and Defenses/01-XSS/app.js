import express from 'express';
import sanitize from 'sanitize-html';
import _ from 'lodash';
import helmet from "helmet";
import validator from 'validator'; // A library of string validators and sanitizers.
import cookieParser from 'cookie-parser';
const app = express();

app.use(
    helmet.contentSecurityPolicy({
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'"],
      },
    })
  );

app.get('/search', (req, res) => {
  const query = req.query.q;
  
//const userInput = '<script>alert("XSS")</script>';

const safeOutput = _.escape(query); // Escape User input not remove it

console.log('Lodash Output ' , safeOutput); // "&lt;script&gt;alert(&quot;XSS&quot;)&lt;/script&gt;"
console.log('Query is ', sanitize(query));
//res.send(query);  
//res.send(`<h1>Hello User , Search Result is ${query}</h1>`);
//const cleanInput = sanitize(query);
  const clean = sanitize(`<h1>Search Results for: ${query}</h1>`);
  // Sanitization removes harmful or unnecessary parts of user input, 
  // ensuring only safe content is allowed.
  res.send(clean);
});

app.use(express.json());
app.use(cookieParser());

app.get('/set-cookie', (req, res) => {
    res.cookie('session', 'secure-session-token', {
      httpOnly: true,
      secure: true, // Use only over HTTPS
    });
    res.send('Cookie set!');
  });

app.post('/submit', (req, res) => {
  const userInput = req.body.input;
  if (validator.isAlphanumeric(userInput)) {
    res.send('Valid input!');
  } else {
    res.status(400).send('Invalid input!');
  }
})
app.listen(3000, (err)=>{
    if(err){
        console.log('Server Crash ', err);
    }
    else{
        console.log('Server Up and Running ');
    }
})

// Attack: http://localhost:3000/search?q=<script>alert('XSS')</script>
// http://localhost:3000/search?q=Hello