import express from 'express';

const app = express();

app.get('/redirect', (req, res) => {
  const { url: redirectTo } = req.query; // Destructure the query parameter

  try {
    const redirectURL = new URL(redirectTo); // Parse the redirect URL

    // Allow redirects only to the same origin
    if (redirectURL.origin === 'https://example.com') {
      res.redirect(redirectTo); // Safe redirect
    } else {
      throw new Error('Invalid origin');
    }
  } catch (error) {
    res.status(400).json({ error: 'Invalid redirect URL' }); // Block unsafe redirect
  }
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});