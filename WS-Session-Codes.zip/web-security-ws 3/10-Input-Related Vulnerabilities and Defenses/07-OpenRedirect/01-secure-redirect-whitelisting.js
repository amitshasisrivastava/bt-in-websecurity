import express from 'express';

const app = express();

// Define a whitelist of safe redirect URLs
const SAFE_URLS = [
  'https://example.com/home',
  'https://example.com/profile'
];

// Redirect route
app.get('/redirect', (req, res) => {
  const { url: redirectTo } = req.query; // Destructure the query parameter

  // Check if the requested URL is in the whitelist
  if (SAFE_URLS.includes(redirectTo)) {
    res.redirect(redirectTo); // Safe redirect
  } else {
    res.status(400).json({ error: 'Invalid redirect URL' }); // Block unsafe redirect
  }
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});