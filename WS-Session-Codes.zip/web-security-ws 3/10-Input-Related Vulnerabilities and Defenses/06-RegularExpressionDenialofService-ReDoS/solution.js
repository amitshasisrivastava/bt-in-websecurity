const RE2 = require('re2');

const regex = new RE2('^(a+)+$'); // RE2 eliminates catastrophic backtracking

function testReDoSSafe(input) {
    if(input.length>100){
        throw new Error('Input is too large...');
    }
  const start = Date.now();
  const match = regex.test(input);
  const duration = Date.now() - start;

  console.log(`Input length: ${input.length}, Time taken: ${duration}ms`);
  return match;
}

const maliciousInput = 'a'.repeat(90) + '!';
testReDoSSafe(maliciousInput);