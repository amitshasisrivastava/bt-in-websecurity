const regex = /^(a+)+$/;

function testReDoS(input) {
  const start = Date.now();
  const match = regex.test(input);
  const duration = Date.now() - start;

  console.log(`Input length: ${input.length}, Time taken: ${duration}ms match `, match);
  return match;
}

const maliciousInput = 'a'.repeat(100) + '!'; // 30 'a's followed by an exclamation mark
console.log('Wait for a result');
testReDoS(maliciousInput); // Attack
testReDoS('abcabcd'); // Normal