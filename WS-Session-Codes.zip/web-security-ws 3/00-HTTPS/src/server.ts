import express, { Request, Response } from "express";
import https from "https";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

// Define __dirname manually for ES Modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Normalize the path to move out of the current directory
const certDirectory = path.normalize(path.join(__dirname, "../cert"));

// Paths for SSL certificates
const sslOptions = {
    key: fs.readFileSync(path.join(certDirectory, "server.key")),
    cert: fs.readFileSync(path.join(certDirectory, "server.cert")),
};

const app = express();

// Middleware to parse JSON
app.use(express.json());

// Routes
app.get("/", (req: Request, res: Response) => {
    res.send("Welcome to the Secure HTTPS Server!");
});

app.post("/data", (req: Request, res: Response) => {
    const data = req.body;
    res.json({ message: "Data received securely!", data });
});

// Create HTTPS server
https.createServer(sslOptions, app).listen(3000, () => {
    console.log("Secure server running at https://localhost:3000");
});