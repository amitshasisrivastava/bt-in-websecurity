const { Quiche } = require('quiche');
const { performance } = require('perf_hooks');

async function testHttp3(url) {
  const quiche = new Quiche();

  // Configure QUIC and HTTP/3
  const options = {
    alpn: 'h3',
    key: '/Users/amitsrivastava/Documents/web-security-ws/00-HTTPS/cert/server.key', // Path to private key
    cert: '/Users/amitsrivastava/Documents/web-security-ws/00-HTTPS/cert/server.cert', // Path to certificate
  };

  const start = performance.now();

  try {
    // Open a QUIC connection
    const connection = quiche.connect(url, options);

    // Send an HTTP/3 GET request
    const streamId = connection.request({
      ':method': 'GET',
      ':path': '/api/articles', // Adjust path as necessary
      ':authority': 'localhost',
    });

    let responseBody = '';

    // Process the response
    connection.on('data', (stream, data, isFin) => {
      if (stream === streamId) {
        responseBody += data.toString();
        if (isFin) {
          const end = performance.now();
          console.log('HTTP/3 Response:', responseBody);
          console.log(`Response Time: ${(end - start).toFixed(2)} ms`);
          connection.close();
        }
      }
    });

    // Run the connection loop
    while (!connection.isClosed()) {
      connection.poll();
    }
  } catch (error) {
    console.error('Error during HTTP/3 request:', error.message);
  }
}

// Run the test
testHttp3('https://localhost:443');