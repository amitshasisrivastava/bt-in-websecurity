import grpc from '@grpc/grpc-js';
import protoLoader from '@grpc/proto-loader';
import path from 'path';

// Load .proto file
const PROTO_PATH = path.resolve('./user.proto');
const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
const userProto = grpc.loadPackageDefinition(packageDefinition).user;

// gRPC Client
const client = new userProto.UserService('localhost:50051', grpc.credentials.createInsecure());

// Request a user by ID
function getUser(id) {
  client.GetUser({ id }, (error, response) => {
    if (error) {
      console.error('Error:', error.details);
    } else {
      console.log('User:', response);
    }
  });
}

// Test with valid and invalid IDs
getUser(1); // Valid
getUser(99); // Invalid