import grpc from '@grpc/grpc-js';
import protoLoader from '@grpc/proto-loader';
import path from 'path';

// Load .proto file
const PROTO_PATH = path.resolve('./user.proto');
const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
const userProto = grpc.loadPackageDefinition(packageDefinition).user;

// Sample User Data
const users = [
  { id: 1, name: 'Ram', email: 'ram@brain-mentors.com' },
  { id: 2, name: 'Ramesh', email: 'ramesh@brain-mentors.com' },
];

// Service implementation
function getUser(call, callback) {
  const userId = call.request.id;
  const user = users.find((u) => u.id === userId);
  if (user) {
    callback(null, user);
  } else {
    callback({
      code: grpc.status.NOT_FOUND,
      details: 'User not found '+userId,
    });
  }
}

// Start the gRPC server
function main() {
  const server = new grpc.Server();
  server.addService(userProto.UserService.service, { GetUser: getUser });
  const PORT = 50051;
  server.bindAsync(`0.0.0.0:${PORT}`, grpc.ServerCredentials.createInsecure(), () => {
    console.log(`Server running at http://localhost:${PORT}`);
    
  });
}

main();