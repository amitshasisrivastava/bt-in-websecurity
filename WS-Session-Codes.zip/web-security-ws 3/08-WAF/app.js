import express from 'express';
import easyWaf from 'easy-waf';
import rateLimit from 'express-rate-limit';
import cookieParser from 'cookie-parser';
import csurf from 'csurf';

const app = express();
app.use(express.json());
app.use(express.urlencoded());
app.use(cookieParser()); // Required for CSRF token to work
// CSRF protection middleware
const csrfProtection = csurf({ cookie: true });

// Set `trust proxy` to a secure configuration
app.set('trust proxy', 'loopback'); // Trust only localhost

// Log IPs for debugging
app.use((req, res, next) => {
    // Firewall stuff
    const  blockIPs =  ['123.45.67.89', '10.90.67.89'];
    const forwardedFor = req.headers['x-forwarded-for'];
    const detectedIP = req.ip;
    console.log(`X-Forwarded-For: ${forwardedFor}, Detected IP: ${detectedIP}`);
    if(blockIPs.indexOf(detectedIP)>=0){
        res.json({"message":"This IP is Blocked"})
    }
    else{
        next(); // call the next middleware
    }
   
  
});



const limiter = rateLimit({
    windowMs: 60 * 1000, // 1 minute
    max: 100, // Limit each IP to 100 requests per windowMs
    message: 'Too many requests from this IP, please try again after a minute.',
    standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
    legacyHeaders: false, // Disable the `X-RateLimit-*` headers,
    trustProxy: false, // Disable proxy trust in rate limiter
});

app.use(limiter);

app.use(
    easyWaf({
       // blockIPs: ['123.45.67.89'], // Block specific IP addresses
        // handler: (req, res) => {
        //     console.log(`Blocked IP detected: ${req.ip}`);
        //     res.status(403).json({
        //         error: 'Forbidden',
        //         message: 'Your IP is blocked.',
        //     });
        // },
        allowedHTTPMethods: ['GET', 'POST'],
        blockSQLi: true, // Enable SQL Injection protection
        blockXSS: true, // Enable XSS protection
       
        /*
        Not working as per expectation , switch for this on express-rate-limit
        rateLimit: {
            max: 10, // Allow 10 requests
            windowMs: 10 * 1000, // Per 10 seconds (adjustable)
            message: 'Too many requests! Please try again later.', // Custom message
            handler: (req, res) => {
                // Custom handler for rate-limited requests
                console.log(`Rate limit exceeded by IP: ${req.ip}`);
                res.status(429).json({
                    error: 'Rate limit exceeded',
                    message: 'Too many requests! Slow down and try again later.',
                });
            },
        }*/
    })
);



/*
// Middleware to block SQL injection
function blockSQLInjection(req, res, next) {
    const sqlInjectionPatterns = [
        /\b(SELECT|INSERT|DELETE|UPDATE|DROP|UNION|WHERE|LIKE|CREATE|ALTER|EXECUTE|MERGE|CALL|ORACLE|SQL|TRUNCATE|--|\/\*)\b/i, // Keywords
        /(['";])/g, // Special characters often used in injections
        /\b(or|and)\b\s+\d+\s*=\s*\d+/i, // Logical SQL conditions (like 1=1)
    ];

    const validateInput = (input) => {
        if (typeof input === 'string') {
            return sqlInjectionPatterns.some((pattern) => pattern.test(input));
        }
        if (typeof input === 'object' && input !== null) {
            return Object.values(input).some(validateInput);
        }
        return false;
    };


    // Check query params, body, and headers for SQL patterns
    const sources = [req.query, req.body, req.headers];
    if (sources.some(validateInput)) {
        return res.status(403).send('Request blocked: SQL Injection detected.');
    }

    next(); // Proceed if no SQL injection detected
}

app.use(blockSQLInjection); // Apply the middleware globally
*/
// Route to serve CSRF token (for client-side applications)
app.get('/csrf-token',csrfProtection, (req, res) => {
    res.cookie('XSRF-TOKEN', req.csrfToken()); // Send the token in a cookie
    res.json({ csrfToken: req.csrfToken() });
});

// Login Route
app.post('/login', (req, res) => {
   
    const { username, password } = req.body;
    console.log('username ', username, 'Password ', password);
    res.send(`Welcome, ${username}!`);
});

app.post('/comments', (req, res) => {
    const { comment } = req.body;
    res.send(`Comment received: ${comment}`);
});
// add rate limit to specific route

app.use('/api/data', limiter);

// also can set dyanmic limits
/*
const dynamicLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: (req, res) => req.query.isVIP ? 1000 : 100, // Higher limit for VIP users
});
app.use('/api/data', dynamicLimiter);
*/
app.get('/api/data', (req, res) => {
    res.send('Getting the API DATA.....');
});
// for CSRF
app.post('/transfer',csrfProtection, (req, res) => {
    const { amount } = req.body;
    res.send(`Transferred ${amount} successfully.`);
});

// Error handling for CSRF token issues
app.use((err, req, res, next) => {
    if (err.code === 'EBADCSRFTOKEN') {
        return res.status(403).json({ error: 'Invalid CSRF token' });
    }
    next(err);
});

const geoMiddleWare  = (req, res, next) => {
    const allowedCountries = ['US', 'IN']; // Example: Only allow US and India
    const country = req.headers['x-country']; // Assume the header contains country info

    if (!allowedCountries.includes(country)) {
        return res.status(403).send('Access denied from your region.');
    }

    next();
};

app.get('/', geoMiddleWare ,(req, res) => {
    res.send('Welcome to the geo-restricted application!');
});

// Start the server
app.listen(3000, () => {
    console.log('Server with WAF is running on port 3000');
});








// Use Case 1: Preventing SQL Injection in a Node.js Application
// SQL Injection Test
// curl -X POST http://localhost:3000/login -d "username=' OR 1=1; --" -d "password=dummy"
// Correct one
//curl -X POST http://localhost:3000/login -d "username=amit" -d "password=abcd123456"


// Use Case 2: Mitigating Cross-Site Scripting (XSS)
// A malicious user injects JavaScript code into a form to execute 
// scripts in other users’ browsers (e.g., stealing cookies).
// Submit a Malicious script
// curl -X POST http://localhost:3000/comments -d "comment=<script>alert('XSS')</script>"
// correct input test
// curl -X POST http://localhost:3000/comments -d "comment=Welcome User"


// Use Case 3: Blocking Bot Traffic
/// Your application is targeted by bots making excessive API requests, causing a denial of service.
// rate limit test
// for i in {1..200}; do curl -s http://localhost:3000/api/data; done
/*
How It Works

	1.	Rate Limiting Rules:
	•	Each IP address can make up to 100 requests in a 1-minute window.
	•	If the limit is exceeded, further requests return a 429 Too Many Requests response with the message: Too many requests from this IP, please try again after a minute.
	2.	Headers:
	•	Standard rate-limit headers (Retry-After, etc.) are included in responses for client awareness.
*/
// correct input test
// curl http://localhost:3000/api/data

// Use Case 4: Blocking Malicious IPs
// Block example
//curl -H "X-Forwarded-For: 123.45.67.89" http://localhost:3000/api/data


// Not Block example
//curl -H "X-Forwarded-For: 10.145.267.89" http://localhost:3000/api/data


// Use Case 5: Preventing Cross-Site Request Forgery (CSRF)
// A malicious site tricks users into submitting requests to your application without their consent.

// Generate Token First
// curl -c cookies.txt http://localhost:3000/csrf-token

// Now do the Call with Token
/*
curl -b cookies.txt -X POST http://localhost:3000/transfer \
-H "Content-Type: application/json" \
-H "csrf-token: your-csrf-token" \
-d '{"amount":1000}'
*/

// same also try with wrong token


// Use Case 6: Allowing Traffic from Specific Countries
// Your application only serves customers in specific countries, 
//but it receives malicious traffic from other regions.

// curl -H "X-Country: US" http://localhost:3000 # Allowed
// curl -H "X-Country: CN" http://localhost:3000 # Blocked