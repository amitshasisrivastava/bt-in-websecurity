import express from 'express';

const app = express();

app.get('/users', (req, res) => {
  res.json({ message: 'User Service: List of Users' });
});

app.listen(3001, () => {
  console.log('Users Service running on port 3001');
});