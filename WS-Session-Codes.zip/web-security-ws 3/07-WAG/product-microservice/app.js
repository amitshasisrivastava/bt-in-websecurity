import express from 'express';

const app = express();

app.get('/products', (req, res) => {
  res.json({ message: 'product Service: List of products' });
});

app.listen(3002, () => {
  console.log('Product Service running on port 3002');
});