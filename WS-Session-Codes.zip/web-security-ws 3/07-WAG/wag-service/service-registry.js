// const serviceRegistry = {
//     '/users': 'http://localhost:3001/users',
//     '/products': 'http://localhost:3002/products',
//     '/orders': 'http://localhost:3003/orders',
//   };
  
//   export default serviceRegistry;


  /*
  2. Scalability

To add scalability, you can introduce multiple instances of each service and dynamically balance traffic across them.

Update Service Registry for Multiple Instances

Modify the serviceRegistry to store multiple instances for each service.
*/
  const serviceRegistry = {
  '/users': ['http://localhost:3001/users', 'http://localhost:3004/users'],
  '/products': ['http://localhost:3002/products', 'http://localhost:3005/products'],
  '/orders': ['http://localhost:3003/orders', 'http://localhost:3006/orders'],
};

export default serviceRegistry;

  