// import express from 'express';
// import { createProxyMiddleware } from 'http-proxy-middleware';
// import serviceRegistry from './service-registry.js';

// const app = express();

// // 1. Dynamic routing in WAG , Reverse Proxy
// Object.keys(serviceRegistry).forEach((route) => {
//   app.use(
//     route,
//     createProxyMiddleware({
//       target: serviceRegistry[route],
//       changeOrigin: true,
//     })
//   );
// });

// // Start the WAG server
// const PORT = 3000;
// app.listen(PORT, () => {
//   console.log(`Web Application Gateway (WAG) is running on port ${PORT}`);
// });

/*
This is how WAG Server works
Client
  |
  V
+--------------------+
| Web Application    |
| Gateway (WAG)      |
+--------------------+
  |      |      |
  V      V      V
User   Product  Order
Service Service Service
*/
/*
To Test WAG Server
http://localhost:3000/orders
http://localhost:3000/users
http://localhost:3000/products
or
curl http://localhost:3000/orders
*/

/*
Implement Round Robin Load Balancing
*/
/*
import express from 'express';
import { createProxyMiddleware } from 'http-proxy-middleware';
import serviceRegistry from './serviceRegistry.js';

const app = express();
const instanceIndex = {};

// Round-robin logic
const getNextInstance = (route) => {
  if (!instanceIndex[route]) {
    instanceIndex[route] = 0;
  }
  const instances = serviceRegistry[route];
  const instance = instances[instanceIndex[route]];
  instanceIndex[route] = (instanceIndex[route] + 1) % instances.length;
  return instance;
};
*/
// Dynamic routing with load balancing and SSL
/*
import https from 'https';
import fs from 'fs';
import express from 'express';
import { createProxyMiddleware } from 'http-proxy-middleware';
import serviceRegistry from './serviceRegistry.js';

const app = express();
const instanceIndex = {};

// Round-robin logic (same as above)
const getNextInstance = (route) => {
  if (!instanceIndex[route]) {
    instanceIndex[route] = 0;
  }
  const instances = serviceRegistry[route];
  const instance = instances[instanceIndex[route]];
  instanceIndex[route] = (instanceIndex[route] + 1) % instances.length;
  return instance;
};

// Dynamic routing with load balancing (same as above)
Object.keys(serviceRegistry).forEach((route) => {
  app.use(
    route,
    (req, res, next) => {
      req.proxyTarget = getNextInstance(route);
      next();
    },
    createProxyMiddleware({
      changeOrigin: true,
      router: (req) => req.proxyTarget,
    })
  );
});
*/
// Load SSL Certificates and RoundRobin with Load Balancing
import https from 'https';
import fs from 'fs';
import express from 'express';
import { createProxyMiddleware } from 'http-proxy-middleware';
import serviceRegistry from './service-registry';

const app = express();
const instanceIndex = {};

// Round-robin logic (same as above)
const getNextInstance = (route) => {
  if (!instanceIndex[route]) {
    instanceIndex[route] = 0;
  }
  const instances = serviceRegistry[route];
  const instance = instances[instanceIndex[route]];
  instanceIndex[route] = (instanceIndex[route] + 1) % instances.length;
  return instance;
};

// Dynamic routing with load balancing (same as above)
Object.keys(serviceRegistry).forEach((route) => {
  app.use(
    route,
    (req, res, next) => {
      req.proxyTarget = getNextInstance(route);
      next();
    },
    createProxyMiddleware({
      changeOrigin: true,
      router: (req) => req.proxyTarget,
    })
  );
});

// Load SSL Certificates
const options = {
  key: fs.readFileSync('server.key'),
  cert: fs.readFileSync('server.cert'),
};

// Start the HTTPS server
const PORT = 3000;
https.createServer(options, app).listen(PORT, () => {
  console.log(`Secure Web Application Gateway (WAG) is running on port ${PORT}`);
});
