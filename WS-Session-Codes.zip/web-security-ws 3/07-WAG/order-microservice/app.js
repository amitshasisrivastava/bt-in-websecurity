import express from 'express';

const app = express();

app.get('/orders', (req, res) => {
  res.json({ message: 'Order Service: List of orders' });
});

app.listen(3003, () => {
  console.log('Order Service running on port 3003');
});